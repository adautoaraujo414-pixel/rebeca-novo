// ========================================
// MIGRATIONS - CRIAÇÃO DAS TABELAS
// ========================================

const { pool } = require('./connection');

const migrations = `
-- ========================================
-- TABELAS PRINCIPAIS
-- ========================================

-- Empresas (clientes da UBMAX)
CREATE TABLE IF NOT EXISTS empresas (
  id SERIAL PRIMARY KEY,
  nome VARCHAR(100) NOT NULL,
  slug VARCHAR(50) UNIQUE,
  telefone_whatsapp VARCHAR(20),
  telefone_admin VARCHAR(20),
  email VARCHAR(100),
  endereco TEXT,
  cidade VARCHAR(100),
  estado VARCHAR(2),
  logo_url TEXT,
  cor_primaria VARCHAR(7) DEFAULT '#3b82f6',
  cor_secundaria VARCHAR(7) DEFAULT '#1e40af',
  nome_assistente VARCHAR(50) DEFAULT 'Rebeca',
  mensagem_boas_vindas TEXT DEFAULT 'Olá! Sou a Rebeca, assistente virtual. Como posso ajudar?',
  ativo BOOLEAN DEFAULT TRUE,
  plano VARCHAR(20) DEFAULT 'basico',
  whatsapp_conectado BOOLEAN DEFAULT FALSE,
  evolution_instance VARCHAR(100),
  criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  atualizado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Configurações da empresa
CREATE TABLE IF NOT EXISTS configuracoes (
  id SERIAL PRIMARY KEY,
  empresa_id INTEGER REFERENCES empresas(id) ON DELETE CASCADE,
  chave VARCHAR(100) NOT NULL,
  valor TEXT,
  tipo VARCHAR(20) DEFAULT 'string',
  criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(empresa_id, chave)
);

-- Motoristas
CREATE TABLE IF NOT EXISTS motoristas (
  id SERIAL PRIMARY KEY,
  empresa_id INTEGER REFERENCES empresas(id) ON DELETE CASCADE,
  nome VARCHAR(100) NOT NULL,
  telefone VARCHAR(20) NOT NULL,
  email VARCHAR(100),
  cpf VARCHAR(14),
  cnh VARCHAR(20),
  senha_hash VARCHAR(64),
  foto_url TEXT,
  veiculo_modelo VARCHAR(100),
  veiculo_placa VARCHAR(10),
  veiculo_cor VARCHAR(30),
  veiculo_ano INTEGER,
  pix_chave VARCHAR(100),
  pix_tipo VARCHAR(20),
  comissao_percentual DECIMAL(5,2) DEFAULT 80.00,
  status VARCHAR(20) DEFAULT 'offline',
  latitude DECIMAL(10,8),
  longitude DECIMAL(11,8),
  ultima_localizacao TIMESTAMP,
  avaliacao_media DECIMAL(3,2) DEFAULT 5.00,
  total_corridas INTEGER DEFAULT 0,
  ativo BOOLEAN DEFAULT TRUE,
  criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  atualizado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Clientes (passageiros)
CREATE TABLE IF NOT EXISTS clientes (
  id SERIAL PRIMARY KEY,
  empresa_id INTEGER REFERENCES empresas(id) ON DELETE CASCADE,
  telefone VARCHAR(20) NOT NULL,
  nome VARCHAR(100),
  email VARCHAR(100),
  cpf VARCHAR(14),
  endereco_favorito TEXT,
  endereco_trabalho TEXT,
  endereco_casa TEXT,
  total_corridas INTEGER DEFAULT 0,
  avaliacao_media DECIMAL(3,2) DEFAULT 5.00,
  bloqueado BOOLEAN DEFAULT FALSE,
  motivo_bloqueio TEXT,
  criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  atualizado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(empresa_id, telefone)
);

-- Corridas
CREATE TABLE IF NOT EXISTS corridas (
  id SERIAL PRIMARY KEY,
  empresa_id INTEGER REFERENCES empresas(id) ON DELETE CASCADE,
  cliente_id INTEGER REFERENCES clientes(id),
  motorista_id INTEGER REFERENCES motoristas(id),
  codigo VARCHAR(10) UNIQUE,
  origem_endereco TEXT NOT NULL,
  origem_referencia TEXT,
  origem_latitude DECIMAL(10,8),
  origem_longitude DECIMAL(11,8),
  destino_endereco TEXT,
  destino_referencia TEXT,
  destino_latitude DECIMAL(10,8),
  destino_longitude DECIMAL(11,8),
  distancia_km DECIMAL(10,2),
  tempo_estimado_min INTEGER,
  valor_estimado DECIMAL(10,2),
  valor_final DECIMAL(10,2),
  forma_pagamento VARCHAR(30),
  status VARCHAR(30) DEFAULT 'aguardando',
  observacoes TEXT,
  avaliacao_cliente INTEGER,
  avaliacao_motorista INTEGER,
  comentario_cliente TEXT,
  comentario_motorista TEXT,
  aceita_em TIMESTAMP,
  iniciada_em TIMESTAMP,
  finalizada_em TIMESTAMP,
  cancelada_em TIMESTAMP,
  motivo_cancelamento TEXT,
  cancelada_por VARCHAR(20),
  criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  atualizado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Pontos de referência
CREATE TABLE IF NOT EXISTS pontos_referencia (
  id SERIAL PRIMARY KEY,
  empresa_id INTEGER REFERENCES empresas(id) ON DELETE CASCADE,
  nome VARCHAR(100) NOT NULL,
  endereco TEXT NOT NULL,
  latitude DECIMAL(10,8),
  longitude DECIMAL(11,8),
  tipo VARCHAR(30),
  ativo BOOLEAN DEFAULT TRUE,
  criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Conversas (histórico de atendimento)
CREATE TABLE IF NOT EXISTS conversas (
  id SERIAL PRIMARY KEY,
  empresa_id INTEGER REFERENCES empresas(id) ON DELETE CASCADE,
  cliente_id INTEGER REFERENCES clientes(id),
  telefone VARCHAR(20) NOT NULL,
  status VARCHAR(30) DEFAULT 'ativo',
  etapa VARCHAR(50) DEFAULT 'inicio',
  contexto JSONB DEFAULT '{}',
  ultima_mensagem TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Mensagens
CREATE TABLE IF NOT EXISTS mensagens (
  id SERIAL PRIMARY KEY,
  conversa_id INTEGER REFERENCES conversas(id) ON DELETE CASCADE,
  empresa_id INTEGER REFERENCES empresas(id) ON DELETE CASCADE,
  direcao VARCHAR(10) NOT NULL,
  tipo VARCHAR(20) DEFAULT 'texto',
  conteudo TEXT,
  midia_url TEXT,
  message_id VARCHAR(100),
  status VARCHAR(20) DEFAULT 'enviada',
  criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Ofertas de corrida (para motoristas)
CREATE TABLE IF NOT EXISTS ofertas_corrida (
  id SERIAL PRIMARY KEY,
  corrida_id INTEGER REFERENCES corridas(id) ON DELETE CASCADE,
  motorista_id INTEGER REFERENCES motoristas(id) ON DELETE CASCADE,
  status VARCHAR(20) DEFAULT 'pendente',
  tempo_resposta_seg INTEGER,
  criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  respondido_em TIMESTAMP
);

-- Pagamentos
CREATE TABLE IF NOT EXISTS pagamentos (
  id SERIAL PRIMARY KEY,
  empresa_id INTEGER REFERENCES empresas(id) ON DELETE CASCADE,
  corrida_id INTEGER REFERENCES corridas(id),
  motorista_id INTEGER REFERENCES motoristas(id),
  tipo VARCHAR(30) NOT NULL,
  valor DECIMAL(10,2) NOT NULL,
  status VARCHAR(20) DEFAULT 'pendente',
  forma_pagamento VARCHAR(30),
  comprovante_url TEXT,
  observacoes TEXT,
  processado_em TIMESTAMP,
  criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Administradores das empresas
CREATE TABLE IF NOT EXISTS admins (
  id SERIAL PRIMARY KEY,
  empresa_id INTEGER REFERENCES empresas(id) ON DELETE CASCADE,
  nome VARCHAR(100) NOT NULL,
  email VARCHAR(100) NOT NULL,
  telefone VARCHAR(20),
  senha_hash VARCHAR(64) NOT NULL,
  cargo VARCHAR(50) DEFAULT 'admin',
  permissoes JSONB DEFAULT '["*"]',
  ativo BOOLEAN DEFAULT TRUE,
  ultimo_acesso TIMESTAMP,
  criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(empresa_id, email)
);

-- Usuários master (UBMAX)
CREATE TABLE IF NOT EXISTS usuarios_master (
  id SERIAL PRIMARY KEY,
  email VARCHAR(100) UNIQUE NOT NULL,
  senha_hash VARCHAR(64) NOT NULL,
  nome VARCHAR(100),
  telefone VARCHAR(20),
  cargo VARCHAR(50) DEFAULT 'operador',
  permissoes JSONB DEFAULT '["*"]',
  ativo BOOLEAN DEFAULT TRUE,
  ultimo_acesso TIMESTAMP,
  criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Horários de funcionamento
CREATE TABLE IF NOT EXISTS horarios_funcionamento (
  id SERIAL PRIMARY KEY,
  empresa_id INTEGER REFERENCES empresas(id) ON DELETE CASCADE,
  dia_semana INTEGER NOT NULL,
  hora_abertura TIME,
  hora_fechamento TIME,
  funciona BOOLEAN DEFAULT TRUE,
  criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tarifas
CREATE TABLE IF NOT EXISTS tarifas (
  id SERIAL PRIMARY KEY,
  empresa_id INTEGER REFERENCES empresas(id) ON DELETE CASCADE,
  nome VARCHAR(50) NOT NULL,
  bandeirada DECIMAL(10,2) DEFAULT 5.00,
  km_rodado DECIMAL(10,2) DEFAULT 2.50,
  minuto_parado DECIMAL(10,2) DEFAULT 0.50,
  valor_minimo DECIMAL(10,2) DEFAULT 10.00,
  ativo BOOLEAN DEFAULT TRUE,
  criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Áreas de atendimento
CREATE TABLE IF NOT EXISTS areas_atendimento (
  id SERIAL PRIMARY KEY,
  empresa_id INTEGER REFERENCES empresas(id) ON DELETE CASCADE,
  nome VARCHAR(100),
  tipo VARCHAR(20) DEFAULT 'poligono',
  coordenadas JSONB,
  valor_adicional DECIMAL(10,2) DEFAULT 0,
  ativo BOOLEAN DEFAULT TRUE,
  criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Logs de atividade
CREATE TABLE IF NOT EXISTS logs_atividade (
  id SERIAL PRIMARY KEY,
  empresa_id INTEGER,
  usuario_tipo VARCHAR(20),
  usuario_id INTEGER,
  acao VARCHAR(100),
  detalhes JSONB,
  ip VARCHAR(45),
  user_agent TEXT,
  criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Notificações
CREATE TABLE IF NOT EXISTS notificacoes (
  id SERIAL PRIMARY KEY,
  empresa_id INTEGER REFERENCES empresas(id) ON DELETE CASCADE,
  usuario_tipo VARCHAR(20),
  usuario_id INTEGER,
  tipo VARCHAR(50),
  titulo VARCHAR(200),
  mensagem TEXT,
  dados JSONB,
  lida BOOLEAN DEFAULT FALSE,
  criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Promoções
CREATE TABLE IF NOT EXISTS promocoes (
  id SERIAL PRIMARY KEY,
  empresa_id INTEGER REFERENCES empresas(id) ON DELETE CASCADE,
  codigo VARCHAR(20) UNIQUE,
  descricao TEXT,
  tipo VARCHAR(20),
  valor DECIMAL(10,2),
  percentual DECIMAL(5,2),
  uso_maximo INTEGER,
  uso_atual INTEGER DEFAULT 0,
  valido_ate TIMESTAMP,
  ativo BOOLEAN DEFAULT TRUE,
  criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Avaliações
CREATE TABLE IF NOT EXISTS avaliacoes (
  id SERIAL PRIMARY KEY,
  corrida_id INTEGER REFERENCES corridas(id) ON DELETE CASCADE,
  avaliador_tipo VARCHAR(20),
  avaliador_id INTEGER,
  avaliado_tipo VARCHAR(20),
  avaliado_id INTEGER,
  nota INTEGER CHECK (nota >= 1 AND nota <= 5),
  comentario TEXT,
  criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ========================================
-- ÍNDICES PARA PERFORMANCE
-- ========================================
CREATE INDEX IF NOT EXISTS idx_motoristas_empresa ON motoristas(empresa_id);
CREATE INDEX IF NOT EXISTS idx_motoristas_status ON motoristas(status);
CREATE INDEX IF NOT EXISTS idx_motoristas_telefone ON motoristas(telefone);
CREATE INDEX IF NOT EXISTS idx_clientes_empresa ON clientes(empresa_id);
CREATE INDEX IF NOT EXISTS idx_clientes_telefone ON clientes(telefone);
CREATE INDEX IF NOT EXISTS idx_corridas_empresa ON corridas(empresa_id);
CREATE INDEX IF NOT EXISTS idx_corridas_status ON corridas(status);
CREATE INDEX IF NOT EXISTS idx_corridas_motorista ON corridas(motorista_id);
CREATE INDEX IF NOT EXISTS idx_corridas_cliente ON corridas(cliente_id);
CREATE INDEX IF NOT EXISTS idx_corridas_criado ON corridas(criado_em);
CREATE INDEX IF NOT EXISTS idx_conversas_empresa ON conversas(empresa_id);
CREATE INDEX IF NOT EXISTS idx_conversas_telefone ON conversas(telefone);
CREATE INDEX IF NOT EXISTS idx_mensagens_conversa ON mensagens(conversa_id);

-- ========================================
-- DADOS INICIAIS
-- ========================================

-- Empresa padrão
INSERT INTO empresas (id, nome, slug, nome_assistente, mensagem_boas_vindas)
VALUES (1, 'Central de Corridas', 'central', 'Rebeca', 'Olá! 👋 Sou a Rebeca, sua assistente virtual. Posso ajudar você a solicitar uma corrida de forma rápida e segura!')
ON CONFLICT (id) DO NOTHING;

-- Tarifa padrão
INSERT INTO tarifas (empresa_id, nome, bandeirada, km_rodado, valor_minimo)
VALUES (1, 'Padrão', 5.00, 2.50, 10.00)
ON CONFLICT DO NOTHING;

-- Admin master padrão (senha: admin123)
INSERT INTO usuarios_master (email, senha_hash, nome, cargo)
VALUES ('admin@ubmax.com', '240be518fabd2724ddb6f04eeb9d5b5a', 'Administrador Master', 'super_admin')
ON CONFLICT (email) DO NOTHING;

-- Horários padrão (segunda a domingo, 24h)
INSERT INTO horarios_funcionamento (empresa_id, dia_semana, hora_abertura, hora_fechamento, funciona)
SELECT 1, d, '00:00', '23:59', true
FROM generate_series(0, 6) AS d
ON CONFLICT DO NOTHING;
`;

const runMigrations = async () => {
  try {
    console.log('🔄 Executando migrations...');
    await pool.query(migrations);
    console.log('✅ Migrations executadas com sucesso!');
    console.log('✅ Banco de dados configurado!');
    return true;
  } catch (error) {
    console.error('❌ Erro nas migrations:', error.message);
    return false;
  }
};

module.exports = { runMigrations };
