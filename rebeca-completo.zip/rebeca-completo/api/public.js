// ========================================
// API PUBLIC - ENDPOINTS PÚBLICOS
// ========================================

const express = require('express');
const router = express.Router();
const { query } = require('../database/connection');

// Status público da empresa
router.get('/empresa/:slug', async (req, res) => {
  try {
    const result = await query(
      'SELECT nome, cor_primaria, nome_assistente, mensagem_boas_vindas FROM empresas WHERE slug = $1 AND ativo = true',
      [req.params.slug]
    );
    
    if (result.rows.length === 0) {
      return res.status(404).json({ success: false, error: 'Empresa não encontrada' });
    }
    
    res.json({ success: true, empresa: result.rows[0] });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Rastrear corrida pelo código
router.get('/rastrear/:codigo', async (req, res) => {
  try {
    const result = await query(`
      SELECT c.codigo, c.status, c.origem_endereco, c.destino_endereco, c.valor_estimado,
             c.criado_em, c.aceita_em, c.iniciada_em, c.finalizada_em,
             m.nome as motorista_nome, m.veiculo_modelo, m.veiculo_placa, m.veiculo_cor
      FROM corridas c
      LEFT JOIN motoristas m ON c.motorista_id = m.id
      WHERE c.codigo = $1
    `, [req.params.codigo.toUpperCase()]);
    
    if (result.rows.length === 0) {
      return res.status(404).json({ success: false, error: 'Corrida não encontrada' });
    }
    
    res.json({ success: true, corrida: result.rows[0] });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = router;
