// ========================================
// API MASTER - PAINEL UBMAX
// ========================================

const express = require('express');
const router = express.Router();
const crypto = require('crypto');
const { query } = require('../database/connection');

// ========================================
// DASHBOARD MASTER
// ========================================
router.get('/dashboard', async (req, res) => {
  try {
    const empresas = await query('SELECT COUNT(*) as total FROM empresas WHERE ativo = true');
    const motoristas = await query('SELECT COUNT(*) as total FROM motoristas WHERE ativo = true');
    const clientes = await query('SELECT COUNT(*) as total FROM clientes');
    const corridas = await query('SELECT COUNT(*) as total FROM corridas');
    const corridasHoje = await query("SELECT COUNT(*) as total FROM corridas WHERE DATE(criado_em) = CURRENT_DATE");
    const faturamentoTotal = await query("SELECT COALESCE(SUM(valor_final), 0) as total FROM corridas WHERE status = 'finalizada'");
    const faturamentoMes = await query(`
      SELECT COALESCE(SUM(valor_final), 0) as total 
      FROM corridas 
      WHERE status = 'finalizada' 
        AND EXTRACT(MONTH FROM criado_em) = EXTRACT(MONTH FROM CURRENT_DATE)
        AND EXTRACT(YEAR FROM criado_em) = EXTRACT(YEAR FROM CURRENT_DATE)
    `);
    
    res.json({
      success: true,
      data: {
        empresas: parseInt(empresas.rows[0]?.total || 0),
        motoristas: parseInt(motoristas.rows[0]?.total || 0),
        clientes: parseInt(clientes.rows[0]?.total || 0),
        corridas: {
          total: parseInt(corridas.rows[0]?.total || 0),
          hoje: parseInt(corridasHoje.rows[0]?.total || 0)
        },
        faturamento: {
          total: parseFloat(faturamentoTotal.rows[0]?.total || 0),
          mes: parseFloat(faturamentoMes.rows[0]?.total || 0)
        }
      }
    });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ========================================
// EMPRESAS
// ========================================
router.get('/empresas', async (req, res) => {
  try {
    const result = await query(`
      SELECT e.*, 
             (SELECT COUNT(*) FROM motoristas WHERE empresa_id = e.id AND ativo = true) as total_motoristas,
             (SELECT COUNT(*) FROM corridas WHERE empresa_id = e.id) as total_corridas,
             (SELECT COALESCE(SUM(valor_final), 0) FROM corridas WHERE empresa_id = e.id AND status = 'finalizada') as faturamento_total
      FROM empresas e 
      ORDER BY e.nome
    `);
    res.json({ success: true, empresas: result.rows });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/empresas/:id', async (req, res) => {
  try {
    const empresa = await query('SELECT * FROM empresas WHERE id = $1', [req.params.id]);
    if (empresa.rows.length === 0) {
      return res.status(404).json({ success: false, error: 'Empresa não encontrada' });
    }
    
    const motoristas = await query('SELECT COUNT(*) as total FROM motoristas WHERE empresa_id = $1 AND ativo = true', [req.params.id]);
    const corridas = await query('SELECT COUNT(*) as total FROM corridas WHERE empresa_id = $1', [req.params.id]);
    const admins = await query('SELECT id, nome, email, cargo FROM admins WHERE empresa_id = $1', [req.params.id]);
    
    res.json({
      success: true,
      empresa: empresa.rows[0],
      stats: {
        motoristas: parseInt(motoristas.rows[0]?.total || 0),
        corridas: parseInt(corridas.rows[0]?.total || 0)
      },
      admins: admins.rows
    });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/empresas', async (req, res) => {
  try {
    const { nome, slug, telefone_whatsapp, email, endereco, cidade, estado, plano, admin_nome, admin_email, admin_senha } = req.body;
    
    // Criar empresa
    const empresaResult = await query(
      `INSERT INTO empresas (nome, slug, telefone_whatsapp, email, endereco, cidade, estado, plano)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
       RETURNING *`,
      [nome, slug, telefone_whatsapp, email, endereco, cidade, estado, plano || 'basico']
    );
    
    const empresa = empresaResult.rows[0];
    
    // Criar admin da empresa
    if (admin_email) {
      const senhaHash = crypto.createHash('md5').update(admin_senha || '123456').digest('hex');
      await query(
        `INSERT INTO admins (empresa_id, nome, email, senha_hash)
         VALUES ($1, $2, $3, $4)`,
        [empresa.id, admin_nome || 'Administrador', admin_email, senhaHash]
      );
    }
    
    // Criar tarifa padrão
    await query(
      `INSERT INTO tarifas (empresa_id, nome, bandeirada, km_rodado, valor_minimo)
       VALUES ($1, 'Padrão', 5.00, 2.50, 10.00)`,
      [empresa.id]
    );
    
    // Criar horários padrão
    for (let dia = 0; dia <= 6; dia++) {
      await query(
        `INSERT INTO horarios_funcionamento (empresa_id, dia_semana, hora_abertura, hora_fechamento, funciona)
         VALUES ($1, $2, '00:00', '23:59', true)`,
        [empresa.id, dia]
      );
    }
    
    res.json({ success: true, empresa });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.put('/empresas/:id', async (req, res) => {
  try {
    const { nome, telefone_whatsapp, email, endereco, cidade, estado, plano, ativo } = req.body;
    
    const result = await query(
      `UPDATE empresas 
       SET nome = COALESCE($1, nome),
           telefone_whatsapp = COALESCE($2, telefone_whatsapp),
           email = COALESCE($3, email),
           endereco = COALESCE($4, endereco),
           cidade = COALESCE($5, cidade),
           estado = COALESCE($6, estado),
           plano = COALESCE($7, plano),
           ativo = COALESCE($8, ativo),
           atualizado_em = CURRENT_TIMESTAMP
       WHERE id = $9
       RETURNING *`,
      [nome, telefone_whatsapp, email, endereco, cidade, estado, plano, ativo, req.params.id]
    );
    
    res.json({ success: true, empresa: result.rows[0] });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.delete('/empresas/:id', async (req, res) => {
  try {
    await query('UPDATE empresas SET ativo = false WHERE id = $1', [req.params.id]);
    res.json({ success: true, message: 'Empresa desativada' });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ========================================
// TODAS CORRIDAS (GLOBAL)
// ========================================
router.get('/corridas', async (req, res) => {
  try {
    const limite = req.query.limite || 100;
    const result = await query(`
      SELECT c.*, e.nome as empresa_nome,
             cl.nome as cliente_nome, cl.telefone as cliente_telefone,
             m.nome as motorista_nome
      FROM corridas c
      LEFT JOIN empresas e ON c.empresa_id = e.id
      LEFT JOIN clientes cl ON c.cliente_id = cl.id
      LEFT JOIN motoristas m ON c.motorista_id = m.id
      ORDER BY c.criado_em DESC
      LIMIT $1
    `, [limite]);
    res.json({ success: true, corridas: result.rows });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ========================================
// TODOS MOTORISTAS (GLOBAL)
// ========================================
router.get('/motoristas', async (req, res) => {
  try {
    const result = await query(`
      SELECT m.*, e.nome as empresa_nome
      FROM motoristas m
      LEFT JOIN empresas e ON m.empresa_id = e.id
      ORDER BY m.nome
    `);
    res.json({ success: true, motoristas: result.rows });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ========================================
// USUÁRIOS MASTER
// ========================================
router.get('/usuarios', async (req, res) => {
  try {
    const result = await query('SELECT id, email, nome, cargo, ativo, ultimo_acesso, criado_em FROM usuarios_master ORDER BY nome');
    res.json({ success: true, usuarios: result.rows });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/usuarios', async (req, res) => {
  try {
    const { email, nome, senha, cargo } = req.body;
    const senhaHash = crypto.createHash('md5').update(senha).digest('hex');
    
    const result = await query(
      `INSERT INTO usuarios_master (email, nome, senha_hash, cargo)
       VALUES ($1, $2, $3, $4)
       RETURNING id, email, nome, cargo`,
      [email, nome, senhaHash, cargo || 'operador']
    );
    
    res.json({ success: true, usuario: result.rows[0] });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ========================================
// RELATÓRIOS GLOBAIS
// ========================================
router.get('/relatorios/geral', async (req, res) => {
  try {
    const corridasPorDia = await query(`
      SELECT DATE(criado_em) as data, COUNT(*) as total, COALESCE(SUM(valor_final), 0) as faturamento
      FROM corridas
      WHERE criado_em >= CURRENT_DATE - INTERVAL '30 days'
      GROUP BY DATE(criado_em)
      ORDER BY data
    `);
    
    const topEmpresas = await query(`
      SELECT e.nome, COUNT(c.id) as corridas, COALESCE(SUM(c.valor_final), 0) as faturamento
      FROM empresas e
      LEFT JOIN corridas c ON e.id = c.empresa_id
      GROUP BY e.id, e.nome
      ORDER BY faturamento DESC
      LIMIT 10
    `);
    
    res.json({
      success: true,
      corridasPorDia: corridasPorDia.rows,
      topEmpresas: topEmpresas.rows
    });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = router;
