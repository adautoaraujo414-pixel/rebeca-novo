// ========================================
// API MOTORISTA - APP DO MOTORISTA
// ========================================

const express = require('express');
const router = express.Router();
const { query } = require('../database/connection');

// Perfil do motorista
router.get('/perfil/:id', async (req, res) => {
  try {
    const result = await query(`
      SELECT m.*, e.nome as empresa_nome
      FROM motoristas m
      LEFT JOIN empresas e ON m.empresa_id = e.id
      WHERE m.id = $1
    `, [req.params.id]);
    
    if (result.rows.length === 0) {
      return res.status(404).json({ success: false, error: 'Motorista não encontrado' });
    }
    
    const motorista = result.rows[0];
    delete motorista.senha_hash;
    
    res.json({ success: true, motorista });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Atualizar status (online/offline/ocupado)
router.put('/status/:id', async (req, res) => {
  try {
    const { status, latitude, longitude } = req.body;
    
    await query(
      `UPDATE motoristas 
       SET status = $1, 
           latitude = COALESCE($2, latitude),
           longitude = COALESCE($3, longitude),
           ultima_localizacao = CURRENT_TIMESTAMP
       WHERE id = $4`,
      [status, latitude, longitude, req.params.id]
    );
    
    // Notificar via Socket
    if (global.io) {
      const motorista = await query('SELECT empresa_id FROM motoristas WHERE id = $1', [req.params.id]);
      if (motorista.rows[0]) {
        global.io.to(`empresa_${motorista.rows[0].empresa_id}`).emit('motorista:status', {
          motoristaId: req.params.id,
          status
        });
      }
    }
    
    res.json({ success: true, status });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Atualizar localização
router.put('/localizacao/:id', async (req, res) => {
  try {
    const { latitude, longitude } = req.body;
    
    await query(
      `UPDATE motoristas 
       SET latitude = $1, longitude = $2, ultima_localizacao = CURRENT_TIMESTAMP
       WHERE id = $3`,
      [latitude, longitude, req.params.id]
    );
    
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Corridas do motorista
router.get('/corridas/:id', async (req, res) => {
  try {
    const status = req.query.status;
    const limite = req.query.limite || 20;
    
    let sql = `
      SELECT c.*, 
             cl.nome as cliente_nome, cl.telefone as cliente_telefone
      FROM corridas c
      LEFT JOIN clientes cl ON c.cliente_id = cl.id
      WHERE c.motorista_id = $1
    `;
    const params = [req.params.id];
    
    if (status) {
      sql += ` AND c.status = $2`;
      params.push(status);
    }
    
    sql += ` ORDER BY c.criado_em DESC LIMIT $${params.length + 1}`;
    params.push(limite);
    
    const result = await query(sql, params);
    res.json({ success: true, corridas: result.rows });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Corrida atual (em andamento)
router.get('/corrida-atual/:id', async (req, res) => {
  try {
    const result = await query(`
      SELECT c.*, 
             cl.nome as cliente_nome, cl.telefone as cliente_telefone
      FROM corridas c
      LEFT JOIN clientes cl ON c.cliente_id = cl.id
      WHERE c.motorista_id = $1 AND c.status IN ('aceita', 'em_andamento')
      ORDER BY c.criado_em DESC
      LIMIT 1
    `, [req.params.id]);
    
    res.json({ 
      success: true, 
      corrida: result.rows[0] || null,
      tem_corrida: result.rows.length > 0
    });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Ofertas de corrida disponíveis
router.get('/ofertas/:id', async (req, res) => {
  try {
    const motorista = await query('SELECT empresa_id FROM motoristas WHERE id = $1', [req.params.id]);
    if (motorista.rows.length === 0) {
      return res.status(404).json({ success: false, error: 'Motorista não encontrado' });
    }
    
    const result = await query(`
      SELECT c.*, cl.nome as cliente_nome, cl.telefone as cliente_telefone
      FROM corridas c
      LEFT JOIN clientes cl ON c.cliente_id = cl.id
      WHERE c.empresa_id = $1 AND c.status = 'aguardando' AND c.motorista_id IS NULL
      ORDER BY c.criado_em DESC
    `, [motorista.rows[0].empresa_id]);
    
    res.json({ success: true, ofertas: result.rows });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Aceitar corrida
router.post('/aceitar-corrida/:motoristaId/:corridaId', async (req, res) => {
  try {
    // Verificar se a corrida ainda está disponível
    const corrida = await query(
      "SELECT * FROM corridas WHERE id = $1 AND status = 'aguardando' AND motorista_id IS NULL",
      [req.params.corridaId]
    );
    
    if (corrida.rows.length === 0) {
      return res.status(400).json({ success: false, error: 'Corrida não disponível' });
    }
    
    // Aceitar a corrida
    const result = await query(
      `UPDATE corridas 
       SET motorista_id = $1, status = 'aceita', aceita_em = CURRENT_TIMESTAMP
       WHERE id = $2
       RETURNING *`,
      [req.params.motoristaId, req.params.corridaId]
    );
    
    // Atualizar status do motorista
    await query("UPDATE motoristas SET status = 'ocupado' WHERE id = $1", [req.params.motoristaId]);
    
    // Notificar via Socket
    if (global.io && result.rows[0]) {
      global.io.to(`empresa_${result.rows[0].empresa_id}`).emit('corrida:aceita', {
        corrida: result.rows[0],
        motoristaId: req.params.motoristaId
      });
    }
    
    res.json({ success: true, corrida: result.rows[0] });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Iniciar corrida
router.post('/iniciar-corrida/:corridaId', async (req, res) => {
  try {
    const result = await query(
      `UPDATE corridas 
       SET status = 'em_andamento', iniciada_em = CURRENT_TIMESTAMP
       WHERE id = $1
       RETURNING *`,
      [req.params.corridaId]
    );
    
    if (global.io && result.rows[0]) {
      global.io.to(`empresa_${result.rows[0].empresa_id}`).emit('corrida:iniciada', result.rows[0]);
    }
    
    res.json({ success: true, corrida: result.rows[0] });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Finalizar corrida
router.post('/finalizar-corrida/:corridaId', async (req, res) => {
  try {
    const { valor_final, forma_pagamento } = req.body;
    
    const result = await query(
      `UPDATE corridas 
       SET status = 'finalizada', 
           finalizada_em = CURRENT_TIMESTAMP,
           valor_final = COALESCE($1, valor_estimado),
           forma_pagamento = $2
       WHERE id = $3
       RETURNING *`,
      [valor_final, forma_pagamento, req.params.corridaId]
    );
    
    // Liberar motorista
    if (result.rows[0]?.motorista_id) {
      await query("UPDATE motoristas SET status = 'online', total_corridas = total_corridas + 1 WHERE id = $1", 
        [result.rows[0].motorista_id]);
    }
    
    // Atualizar total do cliente
    if (result.rows[0]?.cliente_id) {
      await query("UPDATE clientes SET total_corridas = total_corridas + 1 WHERE id = $1",
        [result.rows[0].cliente_id]);
    }
    
    if (global.io && result.rows[0]) {
      global.io.to(`empresa_${result.rows[0].empresa_id}`).emit('corrida:finalizada', result.rows[0]);
    }
    
    res.json({ success: true, corrida: result.rows[0] });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Cancelar corrida
router.post('/cancelar-corrida/:corridaId', async (req, res) => {
  try {
    const { motivo } = req.body;
    
    const result = await query(
      `UPDATE corridas 
       SET status = 'cancelada', 
           cancelada_em = CURRENT_TIMESTAMP,
           motivo_cancelamento = $1,
           cancelada_por = 'motorista'
       WHERE id = $2
       RETURNING *`,
      [motivo, req.params.corridaId]
    );
    
    // Liberar motorista
    if (result.rows[0]?.motorista_id) {
      await query("UPDATE motoristas SET status = 'online' WHERE id = $1", [result.rows[0].motorista_id]);
    }
    
    if (global.io && result.rows[0]) {
      global.io.to(`empresa_${result.rows[0].empresa_id}`).emit('corrida:cancelada', result.rows[0]);
    }
    
    res.json({ success: true, corrida: result.rows[0] });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Estatísticas do motorista
router.get('/estatisticas/:id', async (req, res) => {
  try {
    const hoje = await query(`
      SELECT COUNT(*) as corridas, COALESCE(SUM(valor_final), 0) as faturamento
      FROM corridas 
      WHERE motorista_id = $1 AND DATE(criado_em) = CURRENT_DATE AND status = 'finalizada'
    `, [req.params.id]);
    
    const semana = await query(`
      SELECT COUNT(*) as corridas, COALESCE(SUM(valor_final), 0) as faturamento
      FROM corridas 
      WHERE motorista_id = $1 AND criado_em >= CURRENT_DATE - INTERVAL '7 days' AND status = 'finalizada'
    `, [req.params.id]);
    
    const mes = await query(`
      SELECT COUNT(*) as corridas, COALESCE(SUM(valor_final), 0) as faturamento
      FROM corridas 
      WHERE motorista_id = $1 
        AND EXTRACT(MONTH FROM criado_em) = EXTRACT(MONTH FROM CURRENT_DATE)
        AND status = 'finalizada'
    `, [req.params.id]);
    
    res.json({
      success: true,
      estatisticas: {
        hoje: {
          corridas: parseInt(hoje.rows[0]?.corridas || 0),
          faturamento: parseFloat(hoje.rows[0]?.faturamento || 0)
        },
        semana: {
          corridas: parseInt(semana.rows[0]?.corridas || 0),
          faturamento: parseFloat(semana.rows[0]?.faturamento || 0)
        },
        mes: {
          corridas: parseInt(mes.rows[0]?.corridas || 0),
          faturamento: parseFloat(mes.rows[0]?.faturamento || 0)
        }
      }
    });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = router;
