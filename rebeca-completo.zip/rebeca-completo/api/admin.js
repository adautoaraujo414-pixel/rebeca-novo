// ========================================
// API ADMIN - PAINEL ADMINISTRATIVO
// ========================================

const express = require('express');
const router = express.Router();
const crypto = require('crypto');
const { query } = require('../database/connection');
const { verificarToken } = require('../middlewares/auth');
const { enviarMensagem, gerarQRCode, verificarConexao, desconectar } = require('../whatsapp/evolution');

// ========================================
// DASHBOARD
// ========================================
router.get('/dashboard', async (req, res) => {
  try {
    const empresaId = req.query.empresa_id || 1;
    
    const motoristasOnline = await query(
      "SELECT COUNT(*) as total FROM motoristas WHERE empresa_id = $1 AND status = 'online' AND ativo = true",
      [empresaId]
    );
    
    const motoristasTotal = await query(
      "SELECT COUNT(*) as total FROM motoristas WHERE empresa_id = $1 AND ativo = true",
      [empresaId]
    );
    
    const corridasHoje = await query(
      "SELECT COUNT(*) as total FROM corridas WHERE empresa_id = $1 AND DATE(criado_em) = CURRENT_DATE",
      [empresaId]
    );
    
    const corridasAndamento = await query(
      "SELECT COUNT(*) as total FROM corridas WHERE empresa_id = $1 AND status IN ('aguardando', 'aceita', 'em_andamento')",
      [empresaId]
    );
    
    const faturamentoHoje = await query(
      "SELECT COALESCE(SUM(valor_final), 0) as total FROM corridas WHERE empresa_id = $1 AND DATE(criado_em) = CURRENT_DATE AND status = 'finalizada'",
      [empresaId]
    );
    
    const faturamentoMes = await query(
      "SELECT COALESCE(SUM(valor_final), 0) as total FROM corridas WHERE empresa_id = $1 AND EXTRACT(MONTH FROM criado_em) = EXTRACT(MONTH FROM CURRENT_DATE) AND EXTRACT(YEAR FROM criado_em) = EXTRACT(YEAR FROM CURRENT_DATE) AND status = 'finalizada'",
      [empresaId]
    );
    
    const clientesTotal = await query(
      "SELECT COUNT(*) as total FROM clientes WHERE empresa_id = $1",
      [empresaId]
    );
    
    const corridasTotal = await query(
      "SELECT COUNT(*) as total FROM corridas WHERE empresa_id = $1",
      [empresaId]
    );
    
    res.json({
      success: true,
      data: {
        motoristas: {
          online: parseInt(motoristasOnline.rows[0]?.total || 0),
          total: parseInt(motoristasTotal.rows[0]?.total || 0)
        },
        corridas: {
          hoje: parseInt(corridasHoje.rows[0]?.total || 0),
          andamento: parseInt(corridasAndamento.rows[0]?.total || 0),
          total: parseInt(corridasTotal.rows[0]?.total || 0)
        },
        faturamento: {
          hoje: parseFloat(faturamentoHoje.rows[0]?.total || 0),
          mes: parseFloat(faturamentoMes.rows[0]?.total || 0)
        },
        clientes: {
          total: parseInt(clientesTotal.rows[0]?.total || 0)
        }
      }
    });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ========================================
// MOTORISTAS
// ========================================
router.get('/motoristas', async (req, res) => {
  try {
    const empresaId = req.query.empresa_id || 1;
    const result = await query(
      `SELECT id, nome, telefone, email, status, veiculo_modelo, veiculo_placa, 
              veiculo_cor, avaliacao_media, total_corridas, ativo, criado_em
       FROM motoristas 
       WHERE empresa_id = $1 
       ORDER BY nome`,
      [empresaId]
    );
    res.json({ success: true, motoristas: result.rows });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/motoristas/:id', async (req, res) => {
  try {
    const result = await query('SELECT * FROM motoristas WHERE id = $1', [req.params.id]);
    if (result.rows.length === 0) {
      return res.status(404).json({ success: false, error: 'Motorista não encontrado' });
    }
    res.json({ success: true, motorista: result.rows[0] });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/motoristas', async (req, res) => {
  try {
    const { empresa_id, nome, telefone, email, veiculo_modelo, veiculo_placa, veiculo_cor, senha } = req.body;
    
    const senhaHash = crypto.createHash('md5').update(senha || '123456').digest('hex');
    
    const result = await query(
      `INSERT INTO motoristas (empresa_id, nome, telefone, email, veiculo_modelo, veiculo_placa, veiculo_cor, senha_hash)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
       RETURNING *`,
      [empresa_id || 1, nome, telefone, email, veiculo_modelo, veiculo_placa, veiculo_cor, senhaHash]
    );
    
    res.json({ success: true, motorista: result.rows[0] });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.put('/motoristas/:id', async (req, res) => {
  try {
    const { nome, telefone, email, veiculo_modelo, veiculo_placa, veiculo_cor, ativo } = req.body;
    
    const result = await query(
      `UPDATE motoristas 
       SET nome = COALESCE($1, nome), 
           telefone = COALESCE($2, telefone),
           email = COALESCE($3, email),
           veiculo_modelo = COALESCE($4, veiculo_modelo),
           veiculo_placa = COALESCE($5, veiculo_placa),
           veiculo_cor = COALESCE($6, veiculo_cor),
           ativo = COALESCE($7, ativo),
           atualizado_em = CURRENT_TIMESTAMP
       WHERE id = $8
       RETURNING *`,
      [nome, telefone, email, veiculo_modelo, veiculo_placa, veiculo_cor, ativo, req.params.id]
    );
    
    res.json({ success: true, motorista: result.rows[0] });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.delete('/motoristas/:id', async (req, res) => {
  try {
    await query('UPDATE motoristas SET ativo = false WHERE id = $1', [req.params.id]);
    res.json({ success: true, message: 'Motorista desativado' });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ========================================
// CORRIDAS
// ========================================
router.get('/corridas', async (req, res) => {
  try {
    const empresaId = req.query.empresa_id || 1;
    const status = req.query.status;
    const limite = req.query.limite || 50;
    
    let sql = `
      SELECT c.*, 
             cl.nome as cliente_nome, cl.telefone as cliente_telefone,
             m.nome as motorista_nome, m.telefone as motorista_telefone
      FROM corridas c
      LEFT JOIN clientes cl ON c.cliente_id = cl.id
      LEFT JOIN motoristas m ON c.motorista_id = m.id
      WHERE c.empresa_id = $1
    `;
    const params = [empresaId];
    
    if (status) {
      sql += ` AND c.status = $2`;
      params.push(status);
    }
    
    sql += ` ORDER BY c.criado_em DESC LIMIT $${params.length + 1}`;
    params.push(limite);
    
    const result = await query(sql, params);
    res.json({ success: true, corridas: result.rows });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/corridas/:id', async (req, res) => {
  try {
    const result = await query(`
      SELECT c.*, 
             cl.nome as cliente_nome, cl.telefone as cliente_telefone,
             m.nome as motorista_nome, m.telefone as motorista_telefone
      FROM corridas c
      LEFT JOIN clientes cl ON c.cliente_id = cl.id
      LEFT JOIN motoristas m ON c.motorista_id = m.id
      WHERE c.id = $1
    `, [req.params.id]);
    
    if (result.rows.length === 0) {
      return res.status(404).json({ success: false, error: 'Corrida não encontrada' });
    }
    res.json({ success: true, corrida: result.rows[0] });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/corridas', async (req, res) => {
  try {
    const { empresa_id, cliente_telefone, origem_endereco, destino_endereco, valor_estimado, observacoes } = req.body;
    
    // Buscar ou criar cliente
    let clienteResult = await query(
      'SELECT id FROM clientes WHERE empresa_id = $1 AND telefone = $2',
      [empresa_id || 1, cliente_telefone]
    );
    
    let clienteId;
    if (clienteResult.rows.length === 0) {
      const novoCliente = await query(
        'INSERT INTO clientes (empresa_id, telefone) VALUES ($1, $2) RETURNING id',
        [empresa_id || 1, cliente_telefone]
      );
      clienteId = novoCliente.rows[0].id;
    } else {
      clienteId = clienteResult.rows[0].id;
    }
    
    // Gerar código da corrida
    const codigo = 'C' + Date.now().toString(36).toUpperCase();
    
    const result = await query(
      `INSERT INTO corridas (empresa_id, cliente_id, codigo, origem_endereco, destino_endereco, valor_estimado, observacoes)
       VALUES ($1, $2, $3, $4, $5, $6, $7)
       RETURNING *`,
      [empresa_id || 1, clienteId, codigo, origem_endereco, destino_endereco, valor_estimado, observacoes]
    );
    
    // Emitir evento via Socket
    if (global.io) {
      global.io.to(`empresa_${empresa_id || 1}`).emit('corrida:nova', result.rows[0]);
    }
    
    res.json({ success: true, corrida: result.rows[0] });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.put('/corridas/:id/status', async (req, res) => {
  try {
    const { status, motorista_id, motivo_cancelamento } = req.body;
    
    let updateFields = ['status = $1', 'atualizado_em = CURRENT_TIMESTAMP'];
    let params = [status];
    let paramCount = 1;
    
    if (status === 'aceita' && motorista_id) {
      paramCount++;
      updateFields.push(`motorista_id = $${paramCount}`);
      params.push(motorista_id);
      updateFields.push('aceita_em = CURRENT_TIMESTAMP');
    }
    
    if (status === 'em_andamento') {
      updateFields.push('iniciada_em = CURRENT_TIMESTAMP');
    }
    
    if (status === 'finalizada') {
      updateFields.push('finalizada_em = CURRENT_TIMESTAMP');
    }
    
    if (status === 'cancelada') {
      updateFields.push('cancelada_em = CURRENT_TIMESTAMP');
      if (motivo_cancelamento) {
        paramCount++;
        updateFields.push(`motivo_cancelamento = $${paramCount}`);
        params.push(motivo_cancelamento);
      }
    }
    
    paramCount++;
    params.push(req.params.id);
    
    const result = await query(
      `UPDATE corridas SET ${updateFields.join(', ')} WHERE id = $${paramCount} RETURNING *`,
      params
    );
    
    // Emitir evento via Socket
    if (global.io && result.rows[0]) {
      global.io.to(`empresa_${result.rows[0].empresa_id}`).emit('corrida:update', result.rows[0]);
    }
    
    res.json({ success: true, corrida: result.rows[0] });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ========================================
// CLIENTES
// ========================================
router.get('/clientes', async (req, res) => {
  try {
    const empresaId = req.query.empresa_id || 1;
    const result = await query(
      `SELECT * FROM clientes WHERE empresa_id = $1 ORDER BY nome, telefone`,
      [empresaId]
    );
    res.json({ success: true, clientes: result.rows });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.put('/clientes/:id/bloquear', async (req, res) => {
  try {
    const { bloqueado, motivo } = req.body;
    await query(
      'UPDATE clientes SET bloqueado = $1, motivo_bloqueio = $2 WHERE id = $3',
      [bloqueado, motivo, req.params.id]
    );
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ========================================
// WHATSAPP
// ========================================
router.get('/whatsapp/status-conexao', async (req, res) => {
  try {
    const empresaId = req.query.empresa_id || 1;
    const status = await verificarConexao(empresaId);
    res.json(status);
  } catch (error) {
    res.json({ conectado: false, status: 'erro', error: error.message });
  }
});

router.post('/whatsapp/gerar-qrcode', async (req, res) => {
  try {
    const empresaId = req.body.empresa_id || 1;
    const result = await gerarQRCode(empresaId);
    res.json(result);
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/whatsapp/desconectar', async (req, res) => {
  try {
    const empresaId = req.body.empresa_id || 1;
    await desconectar(empresaId);
    res.json({ success: true, message: 'Desconectado' });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.post('/whatsapp/enviar-mensagem', async (req, res) => {
  try {
    const { telefone, mensagem, empresa_id } = req.body;
    await enviarMensagem(empresa_id || 1, telefone, mensagem);
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ========================================
// CONFIGURAÇÕES
// ========================================
router.get('/configuracoes', async (req, res) => {
  try {
    const empresaId = req.query.empresa_id || 1;
    
    const empresa = await query('SELECT * FROM empresas WHERE id = $1', [empresaId]);
    const configs = await query('SELECT chave, valor FROM configuracoes WHERE empresa_id = $1', [empresaId]);
    const tarifa = await query('SELECT * FROM tarifas WHERE empresa_id = $1 AND ativo = true LIMIT 1', [empresaId]);
    
    res.json({
      success: true,
      empresa: empresa.rows[0],
      configuracoes: configs.rows.reduce((acc, c) => { acc[c.chave] = c.valor; return acc; }, {}),
      tarifa: tarifa.rows[0]
    });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.put('/configuracoes', async (req, res) => {
  try {
    const { empresa_id, configuracoes } = req.body;
    
    for (const [chave, valor] of Object.entries(configuracoes)) {
      await query(
        `INSERT INTO configuracoes (empresa_id, chave, valor) 
         VALUES ($1, $2, $3) 
         ON CONFLICT (empresa_id, chave) DO UPDATE SET valor = $3`,
        [empresa_id || 1, chave, valor]
      );
    }
    
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.put('/configuracoes/empresa', async (req, res) => {
  try {
    const { empresa_id, nome, nome_assistente, mensagem_boas_vindas, cor_primaria } = req.body;
    
    await query(
      `UPDATE empresas 
       SET nome = COALESCE($1, nome),
           nome_assistente = COALESCE($2, nome_assistente),
           mensagem_boas_vindas = COALESCE($3, mensagem_boas_vindas),
           cor_primaria = COALESCE($4, cor_primaria),
           atualizado_em = CURRENT_TIMESTAMP
       WHERE id = $5`,
      [nome, nome_assistente, mensagem_boas_vindas, cor_primaria, empresa_id || 1]
    );
    
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.put('/configuracoes/tarifa', async (req, res) => {
  try {
    const { empresa_id, bandeirada, km_rodado, valor_minimo } = req.body;
    
    await query(
      `UPDATE tarifas 
       SET bandeirada = COALESCE($1, bandeirada),
           km_rodado = COALESCE($2, km_rodado),
           valor_minimo = COALESCE($3, valor_minimo)
       WHERE empresa_id = $4 AND ativo = true`,
      [bandeirada, km_rodado, valor_minimo, empresa_id || 1]
    );
    
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ========================================
// RELATÓRIOS
// ========================================
router.get('/relatorios/corridas', async (req, res) => {
  try {
    const empresaId = req.query.empresa_id || 1;
    const dataInicio = req.query.data_inicio;
    const dataFim = req.query.data_fim;
    
    let sql = `
      SELECT 
        DATE(criado_em) as data,
        COUNT(*) as total,
        SUM(CASE WHEN status = 'finalizada' THEN 1 ELSE 0 END) as finalizadas,
        SUM(CASE WHEN status = 'cancelada' THEN 1 ELSE 0 END) as canceladas,
        COALESCE(SUM(valor_final), 0) as faturamento
      FROM corridas
      WHERE empresa_id = $1
    `;
    const params = [empresaId];
    
    if (dataInicio) {
      params.push(dataInicio);
      sql += ` AND DATE(criado_em) >= $${params.length}`;
    }
    if (dataFim) {
      params.push(dataFim);
      sql += ` AND DATE(criado_em) <= $${params.length}`;
    }
    
    sql += ` GROUP BY DATE(criado_em) ORDER BY data DESC`;
    
    const result = await query(sql, params);
    res.json({ success: true, dados: result.rows });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

router.get('/relatorios/motoristas', async (req, res) => {
  try {
    const empresaId = req.query.empresa_id || 1;
    
    const result = await query(`
      SELECT 
        m.id, m.nome, m.telefone, m.avaliacao_media,
        COUNT(c.id) as total_corridas,
        SUM(CASE WHEN c.status = 'finalizada' THEN 1 ELSE 0 END) as finalizadas,
        COALESCE(SUM(c.valor_final), 0) as faturamento
      FROM motoristas m
      LEFT JOIN corridas c ON m.id = c.motorista_id
      WHERE m.empresa_id = $1 AND m.ativo = true
      GROUP BY m.id
      ORDER BY faturamento DESC
    `, [empresaId]);
    
    res.json({ success: true, dados: result.rows });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = router;
