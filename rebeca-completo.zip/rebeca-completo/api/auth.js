// ========================================
// API AUTH - AUTENTICAÇÃO
// ========================================

const express = require('express');
const router = express.Router();
const crypto = require('crypto');
const jwt = require('jsonwebtoken');
const { query } = require('../database/connection');

const JWT_SECRET = process.env.JWT_SECRET || 'rebeca-secret-key-2024';

// Login Admin
router.post('/admin/login', async (req, res) => {
  try {
    const { email, senha } = req.body;
    
    if (!email || !senha) {
      return res.status(400).json({ success: false, error: 'Email e senha são obrigatórios' });
    }
    
    const senhaHash = crypto.createHash('md5').update(senha).digest('hex');
    
    const result = await query(
      `SELECT a.*, e.nome as empresa_nome 
       FROM admins a 
       LEFT JOIN empresas e ON a.empresa_id = e.id
       WHERE a.email = $1 AND a.senha_hash = $2 AND a.ativo = true`,
      [email, senhaHash]
    );
    
    if (result.rows.length === 0) {
      return res.status(401).json({ success: false, error: 'Credenciais inválidas' });
    }
    
    const admin = result.rows[0];
    
    // Atualizar último acesso
    await query('UPDATE admins SET ultimo_acesso = CURRENT_TIMESTAMP WHERE id = $1', [admin.id]);
    
    const token = jwt.sign(
      { id: admin.id, empresa_id: admin.empresa_id, tipo: 'admin', cargo: admin.cargo },
      JWT_SECRET,
      { expiresIn: '24h' }
    );
    
    res.json({
      success: true,
      token,
      admin: {
        id: admin.id,
        nome: admin.nome,
        email: admin.email,
        cargo: admin.cargo,
        empresa_id: admin.empresa_id,
        empresa_nome: admin.empresa_nome
      }
    });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Login Master
router.post('/master/login', async (req, res) => {
  try {
    const { email, senha } = req.body;
    
    if (!email || !senha) {
      return res.status(400).json({ success: false, error: 'Email e senha são obrigatórios' });
    }
    
    const senhaHash = crypto.createHash('md5').update(senha).digest('hex');
    
    const result = await query(
      'SELECT * FROM usuarios_master WHERE email = $1 AND senha_hash = $2 AND ativo = true',
      [email, senhaHash]
    );
    
    if (result.rows.length === 0) {
      return res.status(401).json({ success: false, error: 'Credenciais inválidas' });
    }
    
    const user = result.rows[0];
    
    // Atualizar último acesso
    await query('UPDATE usuarios_master SET ultimo_acesso = CURRENT_TIMESTAMP WHERE id = $1', [user.id]);
    
    const token = jwt.sign(
      { id: user.id, tipo: 'master', cargo: user.cargo },
      JWT_SECRET,
      { expiresIn: '24h' }
    );
    
    res.json({
      success: true,
      token,
      user: {
        id: user.id,
        nome: user.nome,
        email: user.email,
        cargo: user.cargo
      }
    });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Login Motorista
router.post('/motorista/login', async (req, res) => {
  try {
    const { telefone, senha } = req.body;
    
    if (!telefone || !senha) {
      return res.status(400).json({ success: false, error: 'Telefone e senha são obrigatórios' });
    }
    
    const senhaHash = crypto.createHash('md5').update(senha).digest('hex');
    
    const result = await query(
      `SELECT m.*, e.nome as empresa_nome 
       FROM motoristas m
       LEFT JOIN empresas e ON m.empresa_id = e.id
       WHERE m.telefone = $1 AND m.senha_hash = $2 AND m.ativo = true`,
      [telefone, senhaHash]
    );
    
    if (result.rows.length === 0) {
      return res.status(401).json({ success: false, error: 'Credenciais inválidas' });
    }
    
    const motorista = result.rows[0];
    
    const token = jwt.sign(
      { id: motorista.id, empresa_id: motorista.empresa_id, tipo: 'motorista' },
      JWT_SECRET,
      { expiresIn: '24h' }
    );
    
    res.json({
      success: true,
      token,
      motorista: {
        id: motorista.id,
        nome: motorista.nome,
        telefone: motorista.telefone,
        empresa_id: motorista.empresa_id,
        empresa_nome: motorista.empresa_nome,
        veiculo: {
          modelo: motorista.veiculo_modelo,
          placa: motorista.veiculo_placa,
          cor: motorista.veiculo_cor
        }
      }
    });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Verificar token
router.get('/verificar', (req, res) => {
  try {
    const token = req.headers.authorization?.replace('Bearer ', '');
    
    if (!token) {
      return res.status(401).json({ success: false, error: 'Token não fornecido' });
    }
    
    const decoded = jwt.verify(token, JWT_SECRET);
    res.json({ success: true, user: decoded });
  } catch (error) {
    res.status(401).json({ success: false, error: 'Token inválido' });
  }
});

// Alterar senha
router.post('/alterar-senha', async (req, res) => {
  try {
    const { tipo, id, senha_atual, nova_senha } = req.body;
    
    const senhaAtualHash = crypto.createHash('md5').update(senha_atual).digest('hex');
    const novaSenhaHash = crypto.createHash('md5').update(nova_senha).digest('hex');
    
    let table = tipo === 'master' ? 'usuarios_master' : tipo === 'admin' ? 'admins' : 'motoristas';
    
    const result = await query(
      `UPDATE ${table} SET senha_hash = $1 WHERE id = $2 AND senha_hash = $3 RETURNING id`,
      [novaSenhaHash, id, senhaAtualHash]
    );
    
    if (result.rows.length === 0) {
      return res.status(400).json({ success: false, error: 'Senha atual incorreta' });
    }
    
    res.json({ success: true, message: 'Senha alterada com sucesso' });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = router;
