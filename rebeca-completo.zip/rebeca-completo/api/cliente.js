// ========================================
// API CLIENTE - GESTÃO DE CLIENTES
// ========================================

const express = require('express');
const router = express.Router();
const { query } = require('../database/connection');

// Buscar cliente por telefone
router.get('/telefone/:telefone', async (req, res) => {
  try {
    const empresaId = req.query.empresa_id || 1;
    const result = await query(
      'SELECT * FROM clientes WHERE empresa_id = $1 AND telefone = $2',
      [empresaId, req.params.telefone]
    );
    
    if (result.rows.length === 0) {
      return res.json({ success: true, cliente: null, existe: false });
    }
    
    res.json({ success: true, cliente: result.rows[0], existe: true });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Histórico de corridas do cliente
router.get('/:id/corridas', async (req, res) => {
  try {
    const result = await query(`
      SELECT c.*, m.nome as motorista_nome
      FROM corridas c
      LEFT JOIN motoristas m ON c.motorista_id = m.id
      WHERE c.cliente_id = $1
      ORDER BY c.criado_em DESC
      LIMIT 20
    `, [req.params.id]);
    
    res.json({ success: true, corridas: result.rows });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Atualizar dados do cliente
router.put('/:id', async (req, res) => {
  try {
    const { nome, email, endereco_casa, endereco_trabalho } = req.body;
    
    const result = await query(
      `UPDATE clientes 
       SET nome = COALESCE($1, nome),
           email = COALESCE($2, email),
           endereco_casa = COALESCE($3, endereco_casa),
           endereco_trabalho = COALESCE($4, endereco_trabalho),
           atualizado_em = CURRENT_TIMESTAMP
       WHERE id = $5
       RETURNING *`,
      [nome, email, endereco_casa, endereco_trabalho, req.params.id]
    );
    
    res.json({ success: true, cliente: result.rows[0] });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = router;
