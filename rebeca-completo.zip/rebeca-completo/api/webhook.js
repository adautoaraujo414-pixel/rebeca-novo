// ========================================
// API WEBHOOK - RECEBER MENSAGENS WHATSAPP
// ========================================

const express = require('express');
const router = express.Router();
const { processarMensagem } = require('../whatsapp/fluxo');

// Verificação do webhook (Meta)
router.get('/', (req, res) => {
  const mode = req.query['hub.mode'];
  const token = req.query['hub.verify_token'];
  const challenge = req.query['hub.challenge'];
  
  const verifyToken = process.env.WHATSAPP_WEBHOOK_VERIFY_TOKEN || 'rebeca-verify-token';
  
  if (mode === 'subscribe' && token === verifyToken) {
    console.log('✅ Webhook verificado com sucesso!');
    return res.status(200).send(challenge);
  }
  
  res.sendStatus(403);
});

// Receber mensagens (Meta API)
router.post('/', async (req, res) => {
  try {
    res.sendStatus(200); // Responder rapidamente
    
    const body = req.body;
    
    if (body.object === 'whatsapp_business_account') {
      const entry = body.entry?.[0];
      const changes = entry?.changes?.[0];
      const value = changes?.value;
      
      if (value?.messages) {
        for (const message of value.messages) {
          const telefone = message.from;
          const texto = message.text?.body || message.button?.text || '';
          const tipo = message.type;
          
          console.log(`📱 Mensagem recebida de ${telefone}: ${texto}`);
          
          // Processar mensagem
          await processarMensagem(1, telefone, texto, tipo);
        }
      }
    }
  } catch (error) {
    console.error('❌ Erro no webhook:', error.message);
  }
});

// Webhook Evolution API
router.post('/evolution', async (req, res) => {
  try {
    res.sendStatus(200);
    
    const { event, data, instance } = req.body;
    
    console.log('📱 Evolution webhook:', event);
    
    if (event === 'messages.upsert') {
      const message = data?.message;
      if (message && !message.key?.fromMe) {
        const telefone = message.key?.remoteJid?.replace('@s.whatsapp.net', '');
        const texto = message.message?.conversation || 
                     message.message?.extendedTextMessage?.text ||
                     message.message?.buttonsResponseMessage?.selectedDisplayText || '';
        
        console.log(`📱 Mensagem Evolution de ${telefone}: ${texto}`);
        
        // Buscar empresa pela instância
        const { query } = require('../database/connection');
        const empresa = await query('SELECT id FROM empresas WHERE evolution_instance = $1', [instance]);
        const empresaId = empresa.rows[0]?.id || 1;
        
        await processarMensagem(empresaId, telefone, texto, 'text');
      }
    }
    
    if (event === 'connection.update') {
      const state = data?.state;
      const { query } = require('../database/connection');
      
      if (state === 'open') {
        await query('UPDATE empresas SET whatsapp_conectado = true WHERE evolution_instance = $1', [instance]);
        console.log('✅ WhatsApp conectado:', instance);
      } else if (state === 'close') {
        await query('UPDATE empresas SET whatsapp_conectado = false WHERE evolution_instance = $1', [instance]);
        console.log('❌ WhatsApp desconectado:', instance);
      }
    }
  } catch (error) {
    console.error('❌ Erro no webhook Evolution:', error.message);
  }
});

module.exports = router;
