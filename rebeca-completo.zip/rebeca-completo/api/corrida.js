// ========================================
// API CORRIDA - GESTÃO DE CORRIDAS
// ========================================

const express = require('express');
const router = express.Router();
const { query } = require('../database/connection');
const { calcularValor } = require('../services/tarifa');
const { geocodificar } = require('../services/geocoding');

// Criar nova corrida (via WhatsApp ou manual)
router.post('/nova', async (req, res) => {
  try {
    const { empresa_id, cliente_telefone, cliente_nome, origem_endereco, destino_endereco, observacoes } = req.body;
    
    // Buscar ou criar cliente
    let clienteResult = await query(
      'SELECT id FROM clientes WHERE empresa_id = $1 AND telefone = $2',
      [empresa_id || 1, cliente_telefone]
    );
    
    let clienteId;
    if (clienteResult.rows.length === 0) {
      const novoCliente = await query(
        'INSERT INTO clientes (empresa_id, telefone, nome) VALUES ($1, $2, $3) RETURNING id',
        [empresa_id || 1, cliente_telefone, cliente_nome]
      );
      clienteId = novoCliente.rows[0].id;
    } else {
      clienteId = clienteResult.rows[0].id;
      if (cliente_nome) {
        await query('UPDATE clientes SET nome = $1 WHERE id = $2 AND nome IS NULL', [cliente_nome, clienteId]);
      }
    }
    
    // Geocodificar endereços
    const origemGeo = await geocodificar(origem_endereco);
    const destinoGeo = destino_endereco ? await geocodificar(destino_endereco) : null;
    
    // Calcular valor estimado
    const valorEstimado = await calcularValor(empresa_id || 1, origemGeo, destinoGeo);
    
    // Gerar código único
    const codigo = 'C' + Date.now().toString(36).toUpperCase();
    
    const result = await query(
      `INSERT INTO corridas (
        empresa_id, cliente_id, codigo, 
        origem_endereco, origem_latitude, origem_longitude,
        destino_endereco, destino_latitude, destino_longitude,
        valor_estimado, observacoes
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)
      RETURNING *`,
      [
        empresa_id || 1, clienteId, codigo,
        origem_endereco, origemGeo?.lat, origemGeo?.lon,
        destino_endereco, destinoGeo?.lat, destinoGeo?.lon,
        valorEstimado, observacoes
      ]
    );
    
    // Emitir evento
    if (global.io) {
      global.io.to(`empresa_${empresa_id || 1}`).emit('corrida:nova', result.rows[0]);
    }
    
    res.json({ success: true, corrida: result.rows[0] });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Buscar corrida por código
router.get('/codigo/:codigo', async (req, res) => {
  try {
    const result = await query(`
      SELECT c.*, 
             cl.nome as cliente_nome, cl.telefone as cliente_telefone,
             m.nome as motorista_nome, m.telefone as motorista_telefone,
             m.veiculo_modelo, m.veiculo_placa, m.veiculo_cor
      FROM corridas c
      LEFT JOIN clientes cl ON c.cliente_id = cl.id
      LEFT JOIN motoristas m ON c.motorista_id = m.id
      WHERE c.codigo = $1
    `, [req.params.codigo.toUpperCase()]);
    
    if (result.rows.length === 0) {
      return res.status(404).json({ success: false, error: 'Corrida não encontrada' });
    }
    
    res.json({ success: true, corrida: result.rows[0] });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// Calcular estimativa de valor
router.post('/calcular', async (req, res) => {
  try {
    const { empresa_id, origem, destino } = req.body;
    
    const origemGeo = await geocodificar(origem);
    const destinoGeo = await geocodificar(destino);
    
    if (!origemGeo || !destinoGeo) {
      return res.status(400).json({ success: false, error: 'Não foi possível localizar os endereços' });
    }
    
    const valor = await calcularValor(empresa_id || 1, origemGeo, destinoGeo);
    
    // Calcular distância
    const R = 6371;
    const dLat = (destinoGeo.lat - origemGeo.lat) * Math.PI / 180;
    const dLon = (destinoGeo.lon - origemGeo.lon) * Math.PI / 180;
    const a = Math.sin(dLat/2) * Math.sin(dLat/2) +
              Math.cos(origemGeo.lat * Math.PI / 180) * Math.cos(destinoGeo.lat * Math.PI / 180) *
              Math.sin(dLon/2) * Math.sin(dLon/2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    const distancia = R * c;
    
    res.json({
      success: true,
      estimativa: {
        valor,
        distancia_km: Math.round(distancia * 10) / 10,
        tempo_min: Math.round(distancia * 3)
      }
    });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = router;
