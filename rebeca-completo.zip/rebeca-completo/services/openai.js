// ========================================
// SERVIÇO OPENAI - IA REBECA
// ========================================

const OpenAI = require('openai');
const { query } = require('../database/connection');

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY
});

// Consultar IA
const consultarIA = async (empresaId, telefone, mensagem) => {
  try {
    // Buscar informações da empresa
    const empresa = await query('SELECT nome, nome_assistente FROM empresas WHERE id = $1', [empresaId]);
    const nomeAssistente = empresa.rows[0]?.nome_assistente || 'Rebeca';
    const nomeEmpresa = empresa.rows[0]?.nome || 'Central de Corridas';
    
    // Buscar histórico recente
    const historico = await query(`
      SELECT direcao, conteudo 
      FROM mensagens m
      JOIN conversas c ON m.conversa_id = c.id
      WHERE c.empresa_id = $1 AND c.telefone = $2
      ORDER BY m.criado_em DESC
      LIMIT 10
    `, [empresaId, telefone]);
    
    const mensagensAnteriores = historico.rows.reverse().map(m => ({
      role: m.direcao === 'entrada' ? 'user' : 'assistant',
      content: m.conteudo
    }));
    
    const systemPrompt = `Você é ${nomeAssistente}, assistente virtual da ${nomeEmpresa}.
Você ajuda clientes a solicitar corridas de carro.

REGRAS IMPORTANTES:
1. Seja sempre simpática, educada e profissional
2. Use emojis com moderação para deixar a conversa agradável
3. Seja objetiva nas respostas
4. Se o cliente quer uma corrida, peça o endereço de origem e depois o destino
5. Nunca invente informações sobre preços ou disponibilidade
6. Se não souber algo, diga que vai verificar com a central

CAPACIDADES:
- Solicitar corridas
- Informar sobre corridas anteriores
- Tirar dúvidas sobre o serviço
- Encaminhar para atendente humano quando necessário

Responda de forma natural e amigável.`;

    const response = await openai.chat.completions.create({
      model: 'gpt-4o-mini',
      messages: [
        { role: 'system', content: systemPrompt },
        ...mensagensAnteriores,
        { role: 'user', content: mensagem }
      ],
      max_tokens: 500,
      temperature: 0.7
    });
    
    return response.choices[0]?.message?.content || 
      'Desculpe, não consegui processar. Pode repetir?';
      
  } catch (error) {
    console.error('❌ Erro OpenAI:', error.message);
    return 'Desculpe, estou com dificuldades técnicas. Tente novamente em instantes.';
  }
};

module.exports = { consultarIA };
