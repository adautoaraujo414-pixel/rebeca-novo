// ========================================
// SERVIÇO DE GEOCODIFICAÇÃO
// ========================================

const axios = require('axios');

// Cache simples
const cache = new Map();

// Geocodificar endereço (Nominatim/OpenStreetMap)
const geocodificar = async (endereco) => {
  try {
    if (!endereco) return null;
    
    // Verificar cache
    const cacheKey = endereco.toLowerCase().trim();
    if (cache.has(cacheKey)) {
      return cache.get(cacheKey);
    }
    
    // Adicionar "Brasil" se não tiver país
    let enderecoCompleto = endereco;
    if (!endereco.toLowerCase().includes('brasil') && !endereco.toLowerCase().includes('brazil')) {
      enderecoCompleto = endereco + ', Brasil';
    }
    
    const response = await axios.get('https://nominatim.openstreetmap.org/search', {
      params: {
        q: enderecoCompleto,
        format: 'json',
        limit: 1,
        'accept-language': 'pt-BR'
      },
      headers: {
        'User-Agent': 'REBECA-Sistema-Corridas/2.0'
      },
      timeout: 10000
    });
    
    if (response.data && response.data.length > 0) {
      const resultado = {
        lat: parseFloat(response.data[0].lat),
        lon: parseFloat(response.data[0].lon),
        display_name: response.data[0].display_name
      };
      
      // Salvar no cache
      cache.set(cacheKey, resultado);
      
      // Limpar cache antigo (máximo 1000 entradas)
      if (cache.size > 1000) {
        const firstKey = cache.keys().next().value;
        cache.delete(firstKey);
      }
      
      return resultado;
    }
    
    return null;
  } catch (error) {
    console.error('❌ Erro geocodificação:', error.message);
    return null;
  }
};

// Geocodificação reversa (coordenadas para endereço)
const geocodificarReverso = async (lat, lon) => {
  try {
    const response = await axios.get('https://nominatim.openstreetmap.org/reverse', {
      params: {
        lat,
        lon,
        format: 'json',
        'accept-language': 'pt-BR'
      },
      headers: {
        'User-Agent': 'REBECA-Sistema-Corridas/2.0'
      },
      timeout: 10000
    });
    
    if (response.data) {
      return {
        endereco: response.data.display_name,
        detalhes: response.data.address
      };
    }
    
    return null;
  } catch (error) {
    console.error('❌ Erro geocodificação reversa:', error.message);
    return null;
  }
};

module.exports = { geocodificar, geocodificarReverso };
