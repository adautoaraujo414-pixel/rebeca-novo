// ========================================
// SERVIÇO DE CÁLCULO DE TARIFA
// ========================================

const { query } = require('../database/connection');

// Calcular valor da corrida
const calcularValor = async (empresaId, origem, destino) => {
  try {
    // Buscar tarifa da empresa
    const tarifaResult = await query(
      'SELECT * FROM tarifas WHERE empresa_id = $1 AND ativo = true LIMIT 1',
      [empresaId]
    );
    
    // Tarifa padrão se não encontrar
    const tarifa = tarifaResult.rows[0] || {
      bandeirada: 5.00,
      km_rodado: 2.50,
      valor_minimo: 10.00
    };
    
    // Se não tem destino, retornar valor mínimo
    if (!destino || !origem) {
      return parseFloat(tarifa.valor_minimo);
    }
    
    // Calcular distância (Haversine)
    const R = 6371; // Raio da Terra em km
    const dLat = (destino.lat - origem.lat) * Math.PI / 180;
    const dLon = (destino.lon - origem.lon) * Math.PI / 180;
    const a = Math.sin(dLat/2) * Math.sin(dLat/2) +
              Math.cos(origem.lat * Math.PI / 180) * Math.cos(destino.lat * Math.PI / 180) *
              Math.sin(dLon/2) * Math.sin(dLon/2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    const distancia = R * c;
    
    // Calcular valor
    const bandeirada = parseFloat(tarifa.bandeirada) || 5;
    const kmRodado = parseFloat(tarifa.km_rodado) || 2.5;
    const valorMinimo = parseFloat(tarifa.valor_minimo) || 10;
    
    let valor = bandeirada + (distancia * kmRodado);
    
    // Aplicar valor mínimo
    if (valor < valorMinimo) {
      valor = valorMinimo;
    }
    
    // Arredondar para 2 casas decimais
    return Math.round(valor * 100) / 100;
    
  } catch (error) {
    console.error('❌ Erro ao calcular tarifa:', error.message);
    return 10.00; // Valor padrão em caso de erro
  }
};

module.exports = { calcularValor };
