// ========================================
// FLUXO DE CONVERSA - REBECA IA
// ========================================

const { query } = require('../database/connection');
const { enviarMensagem, enviarBotoes } = require('./evolution');
const { consultarIA } = require('../services/openai');
const { geocodificar } = require('../services/geocoding');
const { calcularValor } = require('../services/tarifa');

// Processar mensagem recebida
const processarMensagem = async (empresaId, telefone, texto, tipo) => {
  try {
    console.log(`🔄 Processando mensagem de ${telefone}: ${texto}`);
    
    // Verificar se cliente está bloqueado
    const clienteCheck = await query(
      'SELECT bloqueado FROM clientes WHERE empresa_id = $1 AND telefone = $2',
      [empresaId, telefone]
    );
    
    if (clienteCheck.rows[0]?.bloqueado) {
      await enviarMensagem(empresaId, telefone, 
        '❌ Desculpe, seu acesso foi bloqueado. Entre em contato com a central.');
      return;
    }
    
    // Buscar ou criar conversa
    let conversa = await query(
      'SELECT * FROM conversas WHERE empresa_id = $1 AND telefone = $2',
      [empresaId, telefone]
    );
    
    if (conversa.rows.length === 0) {
      // Nova conversa
      conversa = await query(
        `INSERT INTO conversas (empresa_id, telefone, etapa, contexto) 
         VALUES ($1, $2, 'inicio', '{}') RETURNING *`,
        [empresaId, telefone]
      );
      
      // Buscar empresa
      const empresa = await query('SELECT nome_assistente, mensagem_boas_vindas FROM empresas WHERE id = $1', [empresaId]);
      const nomeAssistente = empresa.rows[0]?.nome_assistente || 'Rebeca';
      const boasVindas = empresa.rows[0]?.mensagem_boas_vindas || 
        `Olá! 👋 Sou a ${nomeAssistente}, assistente virtual.\n\nComo posso ajudar você hoje?`;
      
      await enviarMensagem(empresaId, telefone, boasVindas);
      await enviarBotoes(empresaId, telefone, 'Escolha uma opção:', [
        '🚗 Solicitar Corrida',
        '📍 Minhas Corridas',
        '💬 Falar com Atendente'
      ]);
      return;
    }
    
    // Atualizar última mensagem
    await query(
      'UPDATE conversas SET ultima_mensagem = CURRENT_TIMESTAMP WHERE id = $1',
      [conversa.rows[0].id]
    );
    
    // Salvar mensagem recebida
    await query(
      'INSERT INTO mensagens (conversa_id, empresa_id, direcao, tipo, conteudo) VALUES ($1, $2, $3, $4, $5)',
      [conversa.rows[0].id, empresaId, 'entrada', tipo, texto]
    );
    
    const etapa = conversa.rows[0].etapa;
    const contexto = conversa.rows[0].contexto || {};
    
    // Processar baseado na etapa
    await processarEtapa(empresaId, telefone, conversa.rows[0].id, etapa, contexto, texto);
    
  } catch (error) {
    console.error('❌ Erro ao processar mensagem:', error.message);
    await enviarMensagem(empresaId, telefone, 
      '😕 Desculpe, tive um problema. Pode repetir, por favor?');
  }
};

// Processar etapa da conversa
const processarEtapa = async (empresaId, telefone, conversaId, etapa, contexto, texto) => {
  const textoLower = texto.toLowerCase().trim();
  
  // Detectar intenção
  if (textoLower.includes('corrida') || textoLower.includes('carro') || 
      textoLower.includes('solicitar') || textoLower === '1' ||
      textoLower.includes('solicitar corrida')) {
    await iniciarSolicitacao(empresaId, telefone, conversaId);
    return;
  }
  
  if (textoLower.includes('minhas corridas') || textoLower.includes('histórico') || textoLower === '2') {
    await mostrarCorridas(empresaId, telefone);
    return;
  }
  
  if (textoLower.includes('atendente') || textoLower.includes('humano') || 
      textoLower.includes('pessoa') || textoLower === '3') {
    await enviarMensagem(empresaId, telefone,
      '👤 Entendi! Vou chamar um atendente humano.\n\nAguarde um momento, por favor...');
    return;
  }
  
  if (textoLower.includes('cancelar')) {
    await atualizarConversa(conversaId, 'inicio', {});
    await enviarMensagem(empresaId, telefone, '✅ Operação cancelada!');
    await enviarBotoes(empresaId, telefone, 'Como posso ajudar?', [
      '🚗 Solicitar Corrida',
      '📍 Minhas Corridas',
      '💬 Falar com Atendente'
    ]);
    return;
  }
  
  // Processar por etapa
  switch (etapa) {
    case 'aguardando_origem':
      await processarOrigem(empresaId, telefone, conversaId, contexto, texto);
      break;
      
    case 'aguardando_destino':
      await processarDestino(empresaId, telefone, conversaId, contexto, texto);
      break;
      
    case 'aguardando_confirmacao':
      await processarConfirmacao(empresaId, telefone, conversaId, contexto, texto);
      break;
      
    case 'aguardando_corrida':
      await verificarStatusCorrida(empresaId, telefone, conversaId, contexto);
      break;
      
    default:
      // Usar IA para entender a intenção
      const resposta = await consultarIA(empresaId, telefone, texto);
      await enviarMensagem(empresaId, telefone, resposta);
  }
};

// Iniciar solicitação de corrida
const iniciarSolicitacao = async (empresaId, telefone, conversaId) => {
  await atualizarConversa(conversaId, 'aguardando_origem', {});
  await enviarMensagem(empresaId, telefone,
    '🚗 *Vamos solicitar sua corrida!*\n\n' +
    '📍 *De onde você quer sair?*\n\n' +
    'Me envie o endereço completo ou sua localização pelo WhatsApp.\n\n' +
    '_Exemplo: Rua das Flores, 123 - Centro_');
};

// Processar endereço de origem
const processarOrigem = async (empresaId, telefone, conversaId, contexto, texto) => {
  const geo = await geocodificar(texto);
  
  if (!geo) {
    await enviarMensagem(empresaId, telefone,
      '😕 Não consegui encontrar esse endereço.\n\n' +
      'Por favor, envie um endereço mais completo:\n' +
      '_Exemplo: Rua das Flores, 123 - Bairro Centro, Cidade_');
    return;
  }
  
  await atualizarConversa(conversaId, 'aguardando_destino', {
    origem: texto,
    origem_lat: geo.lat,
    origem_lon: geo.lon,
    origem_formatado: geo.display_name
  });
  
  await enviarMensagem(empresaId, telefone,
    `✅ *Origem confirmada!*\n\n` +
    `📍 ${geo.display_name || texto}\n\n` +
    `🏁 *Agora me diga: para onde você vai?*\n\n` +
    `_Envie o endereço de destino_`);
};

// Processar endereço de destino
const processarDestino = async (empresaId, telefone, conversaId, contexto, texto) => {
  const geo = await geocodificar(texto);
  
  if (!geo) {
    await enviarMensagem(empresaId, telefone,
      '😕 Não consegui encontrar esse endereço.\n\nPor favor, tente novamente com mais detalhes.');
    return;
  }
  
  // Calcular valor
  const origem = { lat: contexto.origem_lat, lon: contexto.origem_lon };
  const destino = { lat: geo.lat, lon: geo.lon };
  const valor = await calcularValor(empresaId, origem, destino);
  
  // Calcular distância
  const R = 6371;
  const dLat = (destino.lat - origem.lat) * Math.PI / 180;
  const dLon = (destino.lon - origem.lon) * Math.PI / 180;
  const a = Math.sin(dLat/2) * Math.sin(dLat/2) +
            Math.cos(origem.lat * Math.PI / 180) * Math.cos(destino.lat * Math.PI / 180) *
            Math.sin(dLon/2) * Math.sin(dLon/2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
  const distancia = Math.round(R * c * 10) / 10;
  
  await atualizarConversa(conversaId, 'aguardando_confirmacao', {
    ...contexto,
    destino: texto,
    destino_lat: geo.lat,
    destino_lon: geo.lon,
    destino_formatado: geo.display_name,
    valor_estimado: valor,
    distancia_km: distancia
  });
  
  const resumo = 
    `📋 *RESUMO DA SUA CORRIDA*\n\n` +
    `📍 *Origem:*\n${contexto.origem_formatado || contexto.origem}\n\n` +
    `🏁 *Destino:*\n${geo.display_name || texto}\n\n` +
    `📏 *Distância:* ~${distancia} km\n` +
    `💰 *Valor estimado:* R$ ${valor.toFixed(2)}\n\n` +
    `_Confirma a solicitação?_`;
  
  await enviarMensagem(empresaId, telefone, resumo);
  await enviarBotoes(empresaId, telefone, 'Confirma a corrida?', [
    '✅ Confirmar',
    '❌ Cancelar'
  ]);
};

// Processar confirmação
const processarConfirmacao = async (empresaId, telefone, conversaId, contexto, texto) => {
  const textoLower = texto.toLowerCase();
  
  if (textoLower.includes('confirmar') || textoLower.includes('sim') || textoLower === '1' || textoLower === '✅') {
    // Criar corrida
    const codigo = 'C' + Date.now().toString(36).toUpperCase();
    
    // Buscar ou criar cliente
    let cliente = await query(
      'SELECT id FROM clientes WHERE empresa_id = $1 AND telefone = $2',
      [empresaId, telefone]
    );
    
    if (cliente.rows.length === 0) {
      cliente = await query(
        'INSERT INTO clientes (empresa_id, telefone) VALUES ($1, $2) RETURNING id',
        [empresaId, telefone]
      );
    }
    
    const clienteId = cliente.rows[0].id;
    
    // Criar corrida
    const corrida = await query(
      `INSERT INTO corridas (
        empresa_id, cliente_id, codigo,
        origem_endereco, origem_latitude, origem_longitude,
        destino_endereco, destino_latitude, destino_longitude,
        valor_estimado, distancia_km
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)
      RETURNING *`,
      [
        empresaId, clienteId, codigo,
        contexto.origem, contexto.origem_lat, contexto.origem_lon,
        contexto.destino, contexto.destino_lat, contexto.destino_lon,
        contexto.valor_estimado, contexto.distancia_km
      ]
    );
    
    await atualizarConversa(conversaId, 'aguardando_corrida', {
      ...contexto,
      corrida_id: corrida.rows[0].id,
      corrida_codigo: codigo
    });
    
    // Notificar via Socket
    if (global.io) {
      global.io.to(`empresa_${empresaId}`).emit('corrida:nova', corrida.rows[0]);
    }
    
    await enviarMensagem(empresaId, telefone,
      `✅ *CORRIDA SOLICITADA!*\n\n` +
      `📝 *Código:* ${codigo}\n\n` +
      `🔍 Estou procurando um motorista para você...\n\n` +
      `⏱️ Você receberá uma mensagem assim que um motorista aceitar.\n\n` +
      `_Aguarde um momento..._`);
    
  } else {
    await atualizarConversa(conversaId, 'inicio', {});
    await enviarMensagem(empresaId, telefone, '❌ Corrida cancelada!');
    await enviarBotoes(empresaId, telefone, 'Como posso ajudar?', [
      '🚗 Solicitar Corrida',
      '📍 Minhas Corridas',
      '💬 Falar com Atendente'
    ]);
  }
};

// Mostrar corridas do cliente
const mostrarCorridas = async (empresaId, telefone) => {
  const cliente = await query(
    'SELECT id FROM clientes WHERE empresa_id = $1 AND telefone = $2',
    [empresaId, telefone]
  );
  
  if (cliente.rows.length === 0) {
    await enviarMensagem(empresaId, telefone, 
      '📭 Você ainda não tem corridas registradas.\n\nQue tal solicitar a primeira?');
    return;
  }
  
  const corridas = await query(
    `SELECT codigo, origem_endereco, destino_endereco, status, valor_final, criado_em
     FROM corridas 
     WHERE cliente_id = $1
     ORDER BY criado_em DESC
     LIMIT 5`,
    [cliente.rows[0].id]
  );
  
  if (corridas.rows.length === 0) {
    await enviarMensagem(empresaId, telefone, 
      '📭 Você ainda não tem corridas registradas.\n\nQue tal solicitar a primeira?');
    return;
  }
  
  let msg = '📋 *SUAS ÚLTIMAS CORRIDAS:*\n\n';
  
  for (const c of corridas.rows) {
    const status = {
      'aguardando': '⏳ Aguardando',
      'aceita': '✅ Aceita',
      'em_andamento': '🚗 Em andamento',
      'finalizada': '✔️ Finalizada',
      'cancelada': '❌ Cancelada'
    }[c.status] || c.status;
    
    msg += `*${c.codigo}* - ${status}\n`;
    msg += `📍 ${c.origem_endereco?.substring(0, 30)}...\n`;
    if (c.valor_final) msg += `💰 R$ ${parseFloat(c.valor_final).toFixed(2)}\n`;
    msg += '\n';
  }
  
  await enviarMensagem(empresaId, telefone, msg);
};

// Verificar status da corrida
const verificarStatusCorrida = async (empresaId, telefone, conversaId, contexto) => {
  if (!contexto.corrida_id) return;
  
  const corrida = await query('SELECT * FROM corridas WHERE id = $1', [contexto.corrida_id]);
  
  if (corrida.rows.length === 0) return;
  
  const c = corrida.rows[0];
  
  if (c.status === 'aceita' && c.motorista_id) {
    const motorista = await query(
      'SELECT nome, telefone, veiculo_modelo, veiculo_placa, veiculo_cor FROM motoristas WHERE id = $1',
      [c.motorista_id]
    );
    
    if (motorista.rows[0]) {
      const m = motorista.rows[0];
      await enviarMensagem(empresaId, telefone,
        `🎉 *MOTORISTA A CAMINHO!*\n\n` +
        `👤 *Motorista:* ${m.nome}\n` +
        `📱 *Telefone:* ${m.telefone}\n` +
        `🚗 *Veículo:* ${m.veiculo_modelo}\n` +
        `🔢 *Placa:* ${m.veiculo_placa}\n` +
        `🎨 *Cor:* ${m.veiculo_cor}\n\n` +
        `O motorista está a caminho da sua localização!`);
    }
  }
};

// Atualizar conversa
const atualizarConversa = async (conversaId, etapa, contexto) => {
  await query(
    'UPDATE conversas SET etapa = $1, contexto = $2, ultima_mensagem = CURRENT_TIMESTAMP WHERE id = $3',
    [etapa, JSON.stringify(contexto), conversaId]
  );
};

// Notificar cliente sobre atualização de corrida
const notificarCliente = async (corridaId, tipo) => {
  try {
    const corrida = await query(`
      SELECT c.*, cl.telefone, e.id as empresa_id,
             m.nome as motorista_nome, m.telefone as motorista_telefone,
             m.veiculo_modelo, m.veiculo_placa, m.veiculo_cor
      FROM corridas c
      JOIN clientes cl ON c.cliente_id = cl.id
      JOIN empresas e ON c.empresa_id = e.id
      LEFT JOIN motoristas m ON c.motorista_id = m.id
      WHERE c.id = $1
    `, [corridaId]);
    
    if (corrida.rows.length === 0) return;
    
    const c = corrida.rows[0];
    const telefone = c.telefone;
    const empresaId = c.empresa_id;
    
    let mensagem = '';
    
    switch (tipo) {
      case 'aceita':
        mensagem = 
          `🎉 *CORRIDA ACEITA!*\n\n` +
          `👤 *Motorista:* ${c.motorista_nome}\n` +
          `📱 *Telefone:* ${c.motorista_telefone}\n` +
          `🚗 *Veículo:* ${c.veiculo_modelo} - ${c.veiculo_cor}\n` +
          `🔢 *Placa:* ${c.veiculo_placa}\n\n` +
          `O motorista está a caminho! 🚗`;
        break;
        
      case 'iniciada':
        mensagem = `🚗 *CORRIDA INICIADA!*\n\nVocê está a caminho do seu destino.\nBoa viagem! 🛣️`;
        break;
        
      case 'finalizada':
        mensagem = 
          `✅ *CORRIDA FINALIZADA!*\n\n` +
          `💰 *Valor:* R$ ${parseFloat(c.valor_final || c.valor_estimado).toFixed(2)}\n\n` +
          `Obrigada por viajar conosco! 🙏\n` +
          `Até a próxima! 👋`;
        break;
        
      case 'cancelada':
        mensagem = `❌ *CORRIDA CANCELADA*\n\n${c.motivo_cancelamento || 'A corrida foi cancelada.'}\n\nDesculpe pelo transtorno.`;
        break;
    }
    
    if (mensagem) {
      await enviarMensagem(empresaId, telefone, mensagem);
    }
  } catch (error) {
    console.error('❌ Erro ao notificar cliente:', error.message);
  }
};

module.exports = {
  processarMensagem,
  notificarCliente
};
