// ========================================
// WHATSAPP - EVOLUTION API
// ========================================

const axios = require('axios');
const { query } = require('../database/connection');

const EVOLUTION_URL = process.env.EVOLUTION_API_URL || 'http://localhost:8080';
const EVOLUTION_KEY = process.env.EVOLUTION_API_KEY || '';

// Criar cliente axios
const api = axios.create({
  baseURL: EVOLUTION_URL,
  headers: {
    'Content-Type': 'application/json',
    'apikey': EVOLUTION_KEY
  },
  timeout: 30000
});

// Verificar conexão
const verificarConexao = async (empresaId) => {
  try {
    const empresa = await query('SELECT evolution_instance, whatsapp_conectado FROM empresas WHERE id = $1', [empresaId]);
    const instance = empresa.rows[0]?.evolution_instance;
    
    if (!instance) {
      return { conectado: false, status: 'Instância não configurada' };
    }
    
    const response = await api.get(`/instance/connectionState/${instance}`);
    const state = response.data?.state;
    
    if (state === 'open') {
      await query('UPDATE empresas SET whatsapp_conectado = true WHERE id = $1', [empresaId]);
      return { conectado: true, status: 'Conectado' };
    } else {
      await query('UPDATE empresas SET whatsapp_conectado = false WHERE id = $1', [empresaId]);
      return { conectado: false, status: state || 'Desconectado' };
    }
  } catch (error) {
    return { conectado: false, status: 'Erro ao verificar', error: error.message };
  }
};

// Gerar QR Code
const gerarQRCode = async (empresaId) => {
  try {
    const empresa = await query('SELECT nome, slug FROM empresas WHERE id = $1', [empresaId]);
    const instanceName = empresa.rows[0]?.slug || `empresa_${empresaId}`;
    
    // Criar instância se não existir
    try {
      await api.post('/instance/create', {
        instanceName,
        qrcode: true,
        integration: 'WHATSAPP-BAILEYS'
      });
    } catch (e) {
      // Instância já existe
    }
    
    // Conectar e gerar QR
    const response = await api.get(`/instance/connect/${instanceName}`);
    
    // Salvar instância na empresa
    await query('UPDATE empresas SET evolution_instance = $1 WHERE id = $2', [instanceName, empresaId]);
    
    if (response.data?.base64) {
      return {
        success: true,
        qrcode: response.data.base64,
        instance: instanceName
      };
    } else if (response.data?.pairingCode) {
      return {
        success: true,
        pairingCode: response.data.pairingCode,
        instance: instanceName
      };
    }
    
    return { success: false, error: 'QR Code não disponível' };
  } catch (error) {
    return { success: false, error: error.message };
  }
};

// Desconectar
const desconectar = async (empresaId) => {
  try {
    const empresa = await query('SELECT evolution_instance FROM empresas WHERE id = $1', [empresaId]);
    const instance = empresa.rows[0]?.evolution_instance;
    
    if (instance) {
      await api.delete(`/instance/logout/${instance}`);
      await query('UPDATE empresas SET whatsapp_conectado = false WHERE id = $1', [empresaId]);
    }
    
    return { success: true };
  } catch (error) {
    return { success: false, error: error.message };
  }
};

// Enviar mensagem de texto
const enviarMensagem = async (empresaId, telefone, mensagem) => {
  try {
    const empresa = await query('SELECT evolution_instance FROM empresas WHERE id = $1', [empresaId]);
    const instance = empresa.rows[0]?.evolution_instance;
    
    if (!instance) {
      throw new Error('WhatsApp não configurado');
    }
    
    // Formatar telefone
    let numero = telefone.replace(/\D/g, '');
    if (!numero.startsWith('55')) {
      numero = '55' + numero;
    }
    
    const response = await api.post(`/message/sendText/${instance}`, {
      number: numero,
      text: mensagem
    });
    
    // Salvar mensagem no histórico
    await query(
      `INSERT INTO mensagens (empresa_id, direcao, tipo, conteudo, message_id)
       SELECT $1, 'saida', 'texto', $2, $3
       FROM conversas WHERE empresa_id = $1 AND telefone = $4
       LIMIT 1`,
      [empresaId, mensagem, response.data?.key?.id, telefone]
    );
    
    return { success: true, messageId: response.data?.key?.id };
  } catch (error) {
    console.error('❌ Erro ao enviar mensagem:', error.message);
    return { success: false, error: error.message };
  }
};

// Enviar mensagem com botões
const enviarBotoes = async (empresaId, telefone, mensagem, botoes) => {
  try {
    const empresa = await query('SELECT evolution_instance FROM empresas WHERE id = $1', [empresaId]);
    const instance = empresa.rows[0]?.evolution_instance;
    
    if (!instance) {
      throw new Error('WhatsApp não configurado');
    }
    
    let numero = telefone.replace(/\D/g, '');
    if (!numero.startsWith('55')) {
      numero = '55' + numero;
    }
    
    const response = await api.post(`/message/sendButtons/${instance}`, {
      number: numero,
      title: '',
      description: mensagem,
      buttons: botoes.map((b, i) => ({
        type: 'reply',
        buttonId: `btn_${i}`,
        buttonText: { displayText: b }
      }))
    });
    
    return { success: true, messageId: response.data?.key?.id };
  } catch (error) {
    // Fallback para mensagem simples se botões não funcionarem
    const textoComOpcoes = mensagem + '\n\n' + botoes.map((b, i) => `${i + 1}. ${b}`).join('\n');
    return await enviarMensagem(empresaId, telefone, textoComOpcoes);
  }
};

// Enviar localização
const enviarLocalizacao = async (empresaId, telefone, lat, lon, nome, endereco) => {
  try {
    const empresa = await query('SELECT evolution_instance FROM empresas WHERE id = $1', [empresaId]);
    const instance = empresa.rows[0]?.evolution_instance;
    
    if (!instance) {
      throw new Error('WhatsApp não configurado');
    }
    
    let numero = telefone.replace(/\D/g, '');
    if (!numero.startsWith('55')) {
      numero = '55' + numero;
    }
    
    const response = await api.post(`/message/sendLocation/${instance}`, {
      number: numero,
      latitude: lat,
      longitude: lon,
      name: nome || 'Localização',
      address: endereco || ''
    });
    
    return { success: true };
  } catch (error) {
    return { success: false, error: error.message };
  }
};

module.exports = {
  verificarConexao,
  gerarQRCode,
  desconectar,
  enviarMensagem,
  enviarBotoes,
  enviarLocalizacao
};
