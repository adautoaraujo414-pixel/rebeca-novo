// ========================================
// REBECA - SISTEMA COMPLETO DE CORRIDAS
// Central de Atendimento WhatsApp com IA
// ========================================

require('dotenv').config();
const express = require('express');
const cors = require('cors');
const path = require('path');
const http = require('http');
const { Server } = require('socket.io');

const app = express();
const server = http.createServer(app);
const io = new Server(server, {
  cors: { origin: "*", methods: ["GET", "POST"] }
});

// Middlewares globais
app.use(cors());
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

// Servir arquivos estáticos
app.use(express.static(path.join(__dirname, 'public')));

// Variáveis globais
global.io = io;

// Importar rotas
const adminRoutes = require('./api/admin');
const masterRoutes = require('./api/master');
const motoristaRoutes = require('./api/motorista');
const authRoutes = require('./api/auth');
const corridaRoutes = require('./api/corrida');
const clienteRoutes = require('./api/cliente');
const webhookRoutes = require('./api/webhook');
const publicRoutes = require('./api/public');

// Health check
app.get('/health', (req, res) => {
  res.json({ 
    status: 'ok', 
    sistema: 'REBECA',
    versao: '2.1.0',
    timestamp: new Date().toISOString() 
  });
});

app.get('/api/status', (req, res) => {
  res.json({ 
    status: 'online',
    sistema: 'REBECA - Sistema de Corridas',
    versao: '2.1.0',
    ambiente: process.env.NODE_ENV || 'development'
  });
});

// Registrar rotas da API
app.use('/api/admin', adminRoutes);
app.use('/api/master', masterRoutes);
app.use('/api/motorista', motoristaRoutes);
app.use('/api/auth', authRoutes);
app.use('/api/corrida', corridaRoutes);
app.use('/api/cliente', clienteRoutes);
app.use('/api/public', publicRoutes);
app.use('/webhook', webhookRoutes);

// Rotas para os painéis HTML
app.get('/admin', (req, res) => {
  res.sendFile(path.join(__dirname, 'public/admin/index.html'));
});
app.get('/admin/*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public/admin/index.html'));
});

app.get('/master', (req, res) => {
  res.sendFile(path.join(__dirname, 'public/master/index.html'));
});
app.get('/master/*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public/master/index.html'));
});

app.get('/motorista', (req, res) => {
  res.sendFile(path.join(__dirname, 'public/motorista/index.html'));
});
app.get('/motorista/*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public/motorista/index.html'));
});

// Página inicial
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public/index.html'));
});

// Socket.IO - Comunicação em tempo real
io.on('connection', (socket) => {
  console.log('📱 Cliente conectado:', socket.id);
  
  // Motorista entra na sala da empresa
  socket.on('motorista:online', (data) => {
    if (data.empresaId) {
      socket.join(`empresa_${data.empresaId}`);
      socket.join(`motorista_${data.motoristaId}`);
      io.to(`empresa_${data.empresaId}`).emit('motorista:status', {
        motoristaId: data.motoristaId,
        status: 'online'
      });
    }
  });
  
  // Admin entra na sala da empresa
  socket.on('admin:connect', (data) => {
    if (data.empresaId) {
      socket.join(`empresa_${data.empresaId}`);
      socket.join(`admin_${data.empresaId}`);
    }
  });
  
  // Nova corrida
  socket.on('corrida:nova', (data) => {
    io.to(`empresa_${data.empresaId}`).emit('corrida:nova', data);
  });
  
  // Atualização de corrida
  socket.on('corrida:update', (data) => {
    io.to(`empresa_${data.empresaId}`).emit('corrida:update', data);
  });
  
  socket.on('disconnect', () => {
    console.log('📱 Cliente desconectado:', socket.id);
  });
});

// Executar migrations ao iniciar
const { runMigrations } = require('./database/migrate');

// Iniciar servidor
const PORT = process.env.PORT || 3000;
server.listen(PORT, '0.0.0.0', async () => {
  console.log('');
  console.log('╔════════════════════════════════════════════╗');
  console.log('║                                            ║');
  console.log('║   🚗 REBECA - Sistema de Corridas v2.1    ║');
  console.log('║   Central de Atendimento WhatsApp + IA    ║');
  console.log('║                                            ║');
  console.log('╠════════════════════════════════════════════╣');
  console.log('║                                            ║');
  console.log(`║   ✅ Servidor rodando na porta ${PORT}        ║`);
  console.log('║                                            ║');
  console.log('║   📱 Painéis disponíveis:                  ║');
  console.log('║      /admin     - Painel Administrativo   ║');
  console.log('║      /master    - Painel Master (UBMAX)   ║');
  console.log('║      /motorista - App do Motorista        ║');
  console.log('║                                            ║');
  console.log('║   🔗 API:                                  ║');
  console.log('║      /api/status  - Status do sistema     ║');
  console.log('║      /health      - Health check          ║');
  console.log('║      /webhook     - Webhooks WhatsApp     ║');
  console.log('║                                            ║');
  console.log('╚════════════════════════════════════════════╝');
  console.log('');
  
  // Rodar migrations
  await runMigrations();
});

module.exports = { app, server, io };
