// ========================================
// MIDDLEWARE DE AUTENTICAÇÃO
// ========================================

const jwt = require('jsonwebtoken');

const JWT_SECRET = process.env.JWT_SECRET || 'rebeca-secret-key-2024';

// Verificar token JWT
const verificarToken = (req, res, next) => {
  try {
    const authHeader = req.headers.authorization;
    
    if (!authHeader) {
      return res.status(401).json({ success: false, error: 'Token não fornecido' });
    }
    
    const token = authHeader.replace('Bearer ', '');
    const decoded = jwt.verify(token, JWT_SECRET);
    
    req.user = decoded;
    next();
  } catch (error) {
    return res.status(401).json({ success: false, error: 'Token inválido' });
  }
};

// Verificar se é admin
const verificarAdmin = (req, res, next) => {
  if (req.user?.tipo !== 'admin' && req.user?.tipo !== 'master') {
    return res.status(403).json({ success: false, error: 'Acesso negado' });
  }
  next();
};

// Verificar se é master
const verificarMaster = (req, res, next) => {
  if (req.user?.tipo !== 'master') {
    return res.status(403).json({ success: false, error: 'Acesso negado' });
  }
  next();
};

// Verificar se é motorista
const verificarMotorista = (req, res, next) => {
  if (req.user?.tipo !== 'motorista') {
    return res.status(403).json({ success: false, error: 'Acesso negado' });
  }
  next();
};

module.exports = {
  verificarToken,
  verificarAdmin,
  verificarMaster,
  verificarMotorista
};
